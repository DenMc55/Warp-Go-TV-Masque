# Test K - Confirmed Disconnect

Baseline: Test J Protocol Handover Fixed.

Only disconnect handling is changed:

- Keeps Test J's 1800 ms protocol handover delay unchanged.
- Keeps the restored Warp Go TV v1.5 WireGuard backend connect/disconnect calls unchanged.
- On Disconnect, the UI enters a guarded `Disconnecting...` state.
- After requesting disconnect, MainActivity checks actual tunnel state every 100 ms for up to 5 seconds.
- MASQUE is considered down only when both the native tunnel and MasqueVpnService report inactive.
- WireGuard is considered down only when `WarpManager.isUp()` returns false.
- The UI does not assume disconnect succeeded merely because the disconnect call returned.

Purpose: test the intermittent stale/late disconnect behaviour seen on both MASQUE and WireGuard without changing either transport core.
