# Warp Go TV MASQUE Test J — protocol handover guard

Baseline: Test I UI + restored Warp Go TV v1.5 WireGuard lifecycle.

Only intended functional change:
- changing WireGuard <-> MASQUE starts a guarded handover;
- the transport being left is explicitly stopped if still up;
- Connect is ignored while handover is busy;
- wait 1800 ms after teardown before the new protocol can connect.

The proven v1.5 WireGuard connect/disconnect calls remain direct and unchanged.
No prepareWireGuardHandoff, activity relaunch, singleTask, or task-reordering workaround is added.
