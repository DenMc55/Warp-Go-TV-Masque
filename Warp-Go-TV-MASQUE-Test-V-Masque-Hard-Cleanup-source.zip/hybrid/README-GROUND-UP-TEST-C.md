# Warp Go TV — MASQUE Ground-Up Test C (Clean Core)

Purpose: establish a clean-room MASQUE foundation without compiling source from the Chinese reference app.

Test C contains our own:
- Cloudflare WARP device bootstrap registration
- ECDSA P-256 MASQUE enrollment
- atomic local registration persistence
- MASQUE edge discovery
- client certificate generation
- registered edge public-key pinning
- UDP socket setup / Android socket protection hook
- QUIC connection with 20-byte source connection IDs
- HTTP/3 negotiation with datagrams and Extended CONNECT capability check
- English-only user-facing errors

Important: Test C intentionally does **not** create the Android catch-all TUN data path. A successful MASQUE selection reports `MASQUE core ready · Test C`; this proves registration and transport negotiation only. WireGuard remains the working VPN path and is not modified by MASQUE state.

The next stage is to add our own TUN packet/data-path implementation on top of this clean core.
