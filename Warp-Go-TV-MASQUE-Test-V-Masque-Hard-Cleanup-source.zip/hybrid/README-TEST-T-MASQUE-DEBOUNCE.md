# Test T - MASQUE debounce hardening

Baseline: Test S Delayed Clean Restart.

Only change: after a MASQUE connect or disconnect operation completes, MainActivity keeps its existing busy/locked state for an additional 700 ms. During this settle window extra Connect/Disconnect presses are ignored and protocol controls remain disabled.

The successful Test S MASQUE -> WireGuard 5-second clean restart flow is unchanged. WireGuard backend behaviour is unchanged. Protocol registration stores remain separate.
