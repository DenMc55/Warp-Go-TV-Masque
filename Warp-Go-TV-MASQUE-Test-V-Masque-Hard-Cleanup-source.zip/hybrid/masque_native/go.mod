module warpgo/masquecore

go 1.26.0

require (
    github.com/quic-go/quic-go v0.61.0
    golang.org/x/crypto v0.54.0
)
