# Test I UI + WireGuard Activity Fix

Baseline: Test I clean-room MASQUE cf-connect-ip full tunnel on UDP 443.

Changes only:
- MASQUE mode hides the WireGuard-only port heading/help/radio buttons/port note.
- WireGuard mode keeps 4500/2408/500 controls unchanged.
- MainActivity uses singleTask and reasserts the existing activity after successful WireGuard connection so vendor Android/Fire OS does not leave the user at the launcher while the tunnel remains connected.
- Test I MASQUE native transport is unchanged.
- Nuvio add-on compatibility is intentionally not changed in this build.
