# Test I UI + v1.5 WireGuard Restore

This test keeps the Test I UI and clean-room MASQUE implementation, but restores the WireGuard activity/connection lifecycle to the proven Warp Go TV v1.5 behavior.

WireGuard-specific changes from Test I UI WireGuard Fix:
- Removed MainActivity singleTask launch mode.
- Removed onNewIntent task-refresh hook.
- Removed post-connect startActivity/reorder-to-front workaround.
- Removed MASQUE prepareWireGuardHandoff() from the WireGuard connect path.
- WireGuard connect is again directly WarpManager.connect(applicationContext, port), matching v1.5.
- WireGuard disconnect remains directly WarpManager.disconnect(applicationContext), matching v1.5.

MASQUE source/runtime remains separate and unchanged.
