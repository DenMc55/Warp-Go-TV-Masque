package com.iknalos.warpgo

/**
 * JNI status surface for our clean-room MASQUE core.
 * No source from the reference/Chinese WARP app is linked into this module.
 */
object MasqueCore {
    init { System.loadLibrary("warpmasque") }
    external fun nativeIsRunning(): Boolean
    external fun nativeLastError(): String
}
