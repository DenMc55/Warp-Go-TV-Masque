package com.iknalos.warpgo

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.IBinder
import android.os.ParcelFileDescriptor
import androidx.core.app.NotificationCompat

class MasqueVpnService : VpnService() {
    private var pfd: ParcelFileDescriptor? = null
    @Volatile private var shuttingDown = false
    @Volatile private var starting = false

    companion object {
        private const val CHANNEL = "warp_go_masque"
        private const val NOTIFICATION_ID = 4510
        @Volatile private var instance: MasqueVpnService? = null

        init { System.loadLibrary("warpmasque") }

        @JvmStatic private external fun nativePrepare(filesDir: String): String
        @JvmStatic private external fun nativeStart(filesDir: String, fd: Int): String
        @JvmStatic private external fun nativeStop()

        @JvmStatic fun protectSocket(fd: Int): Boolean = try {
            instance?.protect(fd) ?: false
        } catch (_: Throwable) { false }

        fun isServiceActive(): Boolean = instance != null

        fun start(context: Context) {
            val i = Intent(context, MasqueVpnService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(i)
            else context.startService(i)
        }

        fun stop(context: Context) {
            instance?.shutdownForHandoff()
            context.stopService(Intent(context, MasqueVpnService::class.java))
        }

        /**
         * Test V hard cleanup. This deliberately does not touch registration files; it
         * only makes teardown idempotent so repeated MASQUE cycles cannot leave a native
         * core, TUN descriptor, foreground service, or stale service instance running.
         */
        fun forceRuntimeCleanup(context: Context) {
            try { instance?.shutdownForHandoff() } catch (_: Throwable) {}
            try { nativeStop() } catch (_: Throwable) {}
            try { instance?.pfd?.close() } catch (_: Throwable) {}
            try { instance?.pfd = null } catch (_: Throwable) {}
            try { context.stopService(Intent(context, MasqueVpnService::class.java)) } catch (_: Throwable) {}
        }
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIFICATION_ID, notification("Starting MASQUE full tunnel on UDP 443…"))
        if (starting || pfd != null || MasqueCore.nativeIsRunning()) return START_STICKY
        starting = true
        shuttingDown = false

        Thread {
            try {
                // Registration is performed before the full-device TUN exists. This lets
                // Android use Cloudflare's independently assigned MASQUE addresses while
                // leaving the WireGuard account/configuration untouched.
                val prepared = try { nativePrepare(filesDir.absolutePath) }
                catch (t: Throwable) { "ERROR: ${t.message ?: t.javaClass.simpleName}" }
                if (!prepared.startsWith("OK:")) {
                    shutdownForHandoff()
                    return@Thread
                }

                val addresses = prepared.removePrefix("OK:").split("|", limit = 2)
                val v4 = parseAddress(addresses.getOrNull(0).orEmpty(), 32)
                val v6 = parseAddress(addresses.getOrNull(1).orEmpty(), 128)
                if (v4.first.isBlank() && v6.first.isBlank()) {
                    shutdownForHandoff()
                    return@Thread
                }

                val builder = Builder()
                    .setSession("Warp Go TV · MASQUE · UDP 443")
                    .setMtu(1280)
                    .setBlocking(true)

                if (v4.first.isNotBlank()) {
                    builder.addAddress(v4.first, v4.second)
                    builder.addRoute("0.0.0.0", 0)
                    builder.addDnsServer("1.1.1.1")
                    builder.addDnsServer("1.0.0.1")
                }
                if (v6.first.isNotBlank()) {
                    builder.addAddress(v6.first, v6.second)
                    builder.addRoute("::", 0)
                    builder.addDnsServer("2606:4700:4700::1111")
                    builder.addDnsServer("2606:4700:4700::1001")
                }

                val established = try { builder.establish() } catch (_: Throwable) { null }
                if (established == null) {
                    shutdownForHandoff()
                    return@Thread
                }
                pfd = established
                val fd = established.detachFd()
                // detachFd transfers ownership to the Go core.
                pfd = null

                val result = try { nativeStart(filesDir.absolutePath, fd) }
                catch (t: Throwable) { "ERROR: ${t.message ?: t.javaClass.simpleName}" }
                if (result.startsWith("OK:")) {
                    getSystemService(NotificationManager::class.java).notify(
                        NOTIFICATION_ID,
                        notification("MASQUE full tunnel active · UDP 443 · Test I")
                    )
                } else {
                    shutdownForHandoff()
                }
            } finally {
                starting = false
            }
        }.start()

        return START_STICKY
    }

    private fun parseAddress(value: String, fallbackPrefix: Int): Pair<String, Int> {
        val trimmed = value.trim()
        if (trimmed.isBlank() || trimmed.startsWith("/")) return "" to fallbackPrefix
        val slash = trimmed.lastIndexOf('/')
        if (slash <= 0) return trimmed to fallbackPrefix
        val host = trimmed.substring(0, slash)
        val prefix = trimmed.substring(slash + 1).toIntOrNull() ?: fallbackPrefix
        return host to prefix
    }

    @Synchronized
    private fun shutdownForHandoff() {
        if (shuttingDown) return
        shuttingDown = true
        try { nativeStop() } catch (_: Throwable) {}
        try { pfd?.close() } catch (_: Throwable) {}
        pfd = null
        try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (_: Throwable) {}
        try { stopSelf() } catch (_: Throwable) {}
        // Keep instance non-null until Android actually calls onDestroy().
        // This makes isServiceActive() a real lifecycle signal rather than
        // reporting DOWN while the old VpnService is still being destroyed.
    }

    override fun onRevoke() {
        shutdownForHandoff()
        super.onRevoke()
    }

    override fun onDestroy() {
        shutdownForHandoff()
        if (instance === this) instance = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = super.onBind(intent)

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(CHANNEL, "Warp Go TV MASQUE", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    private fun notification(text: String) = NotificationCompat.Builder(this, CHANNEL)
        .setSmallIcon(android.R.drawable.stat_sys_download_done)
        .setContentTitle("Warp Go TV")
        .setContentText(text)
        .setOngoing(true)
        .setPriority(NotificationCompat.PRIORITY_LOW)
        .setContentIntent(
            PendingIntent.getActivity(
                this, 0, Intent(this, MainActivity::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        )
        .build()
}
