# Warp Go TV MASQUE Ground-Up Test G — Full Tunnel / UDP 443

Test G builds directly from the proven Test F clean-room source. It does not import, compile or graft MASQUE code from the Chinese/reference WARP app.

## Test G goals

- Keep the existing WireGuard implementation intact.
- Keep WireGuard and MASQUE Cloudflare registration/state sandboxed from each other.
- Use the independent MASQUE registration file `masque_clean_reg.json` only for MASQUE.
- Force the MASQUE outer transport to **UDP port 443**.
- Establish QUIC + TLS 1.3 + HTTP/3 with datagrams.
- Open an authenticated RFC 9484 **CONNECT-IP** request using the standard MASQUE path.
- Establish a full-device Android TUN using the IP addresses assigned to the MASQUE registration.
- Route IPv4/IPv6 device traffic into the TUN and forward complete IP packets over HTTP/3 datagrams with CONNECT-IP Context ID 0.
- Forward received CONNECT-IP datagrams back into the Android TUN.
- Protect the outer UDP/443 socket with `VpnService.protect()` so it cannot loop back into the tunnel.

## Expected success status

`MASQUE full tunnel · UDP 443 · Test G`

A successful status means the CONNECT-IP request returned 2xx and the bidirectional TUN/datagram pumps are running. The practical confirmation is that ordinary Internet traffic still works while MASQUE is selected and an external trace reports WARP active.

## Isolation rule

The MASQUE registration, P-256 private key, token, assigned addresses and runtime state belong only to MASQUE. Test G does not overwrite or reuse WireGuard's account/configuration. Switching protocols only hands Android VPN ownership from one service to the other.

## Reference-app rule

The Chinese/reference WARP app may be studied to understand behaviour, but none of its MASQUE source is compiled or copied into this project. The native MASQUE core in `masque_native/bridge.go` is our clean-room implementation using Go, quic-go and Android VpnService/JNI.
