# Test M – MASQUE to WireGuard confirmed handover

Based on Test L. The WireGuard -> MASQUE path remains unchanged.

For MASQUE -> WireGuard only:
- stop MASQUE if active;
- wait up to 5 seconds until both the MASQUE native core and MasqueVpnService report down;
- add a 500 ms VPN-ownership release guard;
- only then return control so WireGuard can be connected.

If MASQUE does not fully stop in time, WireGuard is not started and the UI reports the timeout.
