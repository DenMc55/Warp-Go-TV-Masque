# Warp Go TV MASQUE Ground-Up Test D — Diagnostic

Purpose: isolate the clean-room MASQUE startup crash without changing the proven WireGuard path.

Changes from Test C:
- fixes the JNI class mismatch in the clean-core test path: `nativeTest` no longer asks the `MasqueGraft` class for `protectSocket`;
- clears a JNI lookup exception defensively if the VpnService protection method is unavailable;
- writes a persistent MASQUE stage marker before each registration / socket / QUIC / HTTP3 step;
- shows the last MASQUE diagnostic stage in the UI after reopening the app;
- catches `Throwable` around the MASQUE JNI test path where Android permits recovery;
- keeps WireGuard logic unchanged;
- no Chinese/reference MASQUE implementation is compiled into this module;
- still does not install a catch-all MASQUE TUN. Test D is a diagnostic core test only.

A successful test ends at:
`14 MASQUE core ready; Extended CONNECT advertised`
