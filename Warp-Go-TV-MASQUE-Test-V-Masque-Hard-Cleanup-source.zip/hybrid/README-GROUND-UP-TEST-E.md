# Warp Go TV MASQUE Ground-Up Test E — VpnService integration

Baseline: Test D clean diagnostic, which reached stage 14: MASQUE core ready / Extended CONNECT advertised.

Test E changes only the Android service integration layer:
- MASQUE Connect now starts the real `MasqueVpnService`;
- the service establishes a limited diagnostic TUN route (`198.18.0.0/15`), not a catch-all tunnel;
- the clean QUIC socket must pass through Android `VpnService.protect()`;
- the same clean-room MASQUE registration + QUIC/HTTP3 core is retained;
- WireGuard remains unchanged;
- no Chinese/reference MASQUE source is compiled;
- no TUN packet forwarding is implemented yet.

Success condition:
`MASQUE service + core ready · Test E`

This proves that the MASQUE core survives inside the real Android VpnService and that socket protection works. Full TUN packet forwarding is intentionally deferred to the next stage.
