# Test S - MASQUE to WireGuard clean restart

Baseline: Test M.

Only MASQUE -> WireGuard changes behaviour. When selected while disconnected, the UI stays open and shows a five-second restart countdown. The selected protocol is saved as WireGuard, auto-restore intent is cleared, a self-relaunch is scheduled, and the current app process is then terminated. Android/Fire OS relaunches Warp Go in a fresh process with WireGuard selected and disconnected.

WireGuard -> MASQUE retains Test M handover behaviour. Protocol controls and WireGuard port controls remain locked while connected/busy. WireGuard and MASQUE registrations remain separately sandboxed.
