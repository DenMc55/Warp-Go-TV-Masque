# Warp Go TV MASQUE Ground-Up Test F

Test F continues the clean-room MASQUE implementation one controlled layer at a time.

## What Test F adds

- Keeps WireGuard as the existing known-good Warp Go TV implementation.
- Keeps MASQUE registration/state sandboxed from WireGuard.
- Retains the limited diagnostic Android VpnService route (`198.18.0.0/15`).
- Retains VpnService socket protection and QUIC/HTTP/3 setup from Test E.
- Adds one authenticated HTTP/3 CONNECT probe through the Cloudflare MASQUE edge to `1.1.1.1:443`.
- Immediately closes the probe stream after a successful HTTP 200 response.
- Does **not** yet forward TUN packets through MASQUE.
- Adds an explicit MASQUE-to-WireGuard handoff barrier: native state, diagnostic TUN and service state are synchronously released before WireGuard can start.

## Expected result

1. WireGuard still connects/disconnects normally when MASQUE has not been used.
2. MASQUE reaches `MASQUE core + CONNECT probe ready · Test F`.
3. Disconnecting MASQUE releases its service/core state cleanly.
4. Switching back to WireGuard then connects without closing the Activity.

If Test F succeeds, the next step is to begin attaching controlled TUN traffic to the proven MASQUE CONNECT path.
