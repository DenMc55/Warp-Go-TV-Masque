# Warp Go TV MASQUE Ground-Up Test I — Cloudflare cf-connect-ip fix on UDP/443

Test I is built directly from Test H. Test H proved that the protected IPv4 UDP/443 path, QUIC/TLS and HTTP/3 setup reached the Cloudflare edge, but its RFC-style CONNECT-IP request was rejected with HTTP 403.

Test I keeps the Test H Android TUN, IPv4 preference, UDP/443 outer transport, registration isolation and packet pumps, and corrects the Cloudflare WARP H3 request profile:

- use `cf-connect-ip` rather than RFC `connect-ip` as the Extended CONNECT protocol;
- use `https://cloudflareaccess.com/` as the CONNECT authority/URI;
- authenticate the tunnel with the enrolled P-256 TLS client key/certificate, not the registration API bearer token;
- use the Cloudflare WARP MASQUE SNI `consumer-masque.cloudflareclient.com`;
- send the legacy HTTP/3 datagram setting `0x276 = 1` in addition to RFC datagram support;
- do not reject the edge merely because it omits SETTINGS_ENABLE_CONNECT_PROTOCOL, a known WARP quirk;
- retain the clean-room rule: no Chinese/reference app source is imported or compiled.

Expected success status:

`MASQUE full tunnel · UDP 443 · Test I`

The diagnostic file is `masque_testi_stage.txt`.
