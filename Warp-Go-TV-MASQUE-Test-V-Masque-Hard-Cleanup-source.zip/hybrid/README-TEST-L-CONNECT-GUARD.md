# Warp Go TV – Test L: Connect Guard + WireGuard Port Lock

Baseline: Test K Confirmed Disconnect.

Only these behaviours are added:

1. Connection attempts are bounded to 10 seconds. If the selected transport does not
   complete in that time, the attempt is cleaned up and the UI returns to a usable state.
   A timed-out MASQUE attempt explicitly stops its service/native tunnel. WireGuard uses
   the unchanged v1.5 backend and is only disconnected on timeout if it actually reports up.
2. WireGuard port choices (4500 / 2408 / 500) are disabled while WireGuard is connecting,
   connected, or disconnecting. They become selectable again only after WireGuard is down.

Unchanged from Test K:
- 1.8 second protocol handover settling delay.
- confirmed-disconnect polling (100 ms, up to 5 seconds).
- Test I clean-room MASQUE implementation.
- proven v1.5 WireGuard connect/disconnect backend path.
- no singleTask/task-reordering/activity relaunch workaround.
