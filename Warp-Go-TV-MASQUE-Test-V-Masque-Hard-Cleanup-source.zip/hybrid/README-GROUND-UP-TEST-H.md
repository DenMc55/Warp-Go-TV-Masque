# Warp Go TV MASQUE Ground-Up Test H — IPv4 full-tunnel fix

Test H is built directly from the supplied Test G full-tunnel source. It keeps the clean-room MASQUE implementation and does not import or compile source from the Chinese/reference app.

## Test G finding fixed

Test G reached the full-tunnel startup path but the final failure shown was:

`QUIC UDP/443 [2606:4700:103::2]:443 ... network is unreachable`

That is an IPv6 reachability failure on the underlying network, not evidence that the clean MASQUE registration, QUIC/HTTP3 implementation or UDP/443 path is wrong. Test H therefore makes the outer MASQUE transport deterministic:

- use the registered IPv4 MASQUE edge on UDP/443 whenever one is available;
- do not fall through to an unusable IPv6 endpoint and replace the useful IPv4 diagnostic;
- use IPv6 only if the registration supplies no IPv4 MASQUE endpoint;
- keep the protected outer socket, QUIC/TLS 1.3, HTTP/3 datagrams, RFC 9484 CONNECT-IP, Android TUN and bidirectional packet pumps from Test G;
- keep MASQUE registration/state isolated from WireGuard.

## Expected success status

`MASQUE full tunnel · UDP 443 · Test H`

If Test H fails, the displayed error should now describe the real IPv4 MASQUE attempt rather than an irrelevant IPv6 `network is unreachable` fallback.
