# Test U – MASQUE Fresh Session

Built directly on Test T.

Changes only the MASQUE reconnect lifecycle:

- `MasqueVpnService.isServiceActive()` now remains true until Android actually calls `onDestroy()`.
- After a confirmed MASQUE disconnect, the app waits 1 second before re-enabling controls.
- The next MASQUE Connect therefore starts a new `VpnService` instance and a fresh native session.
- Test S delayed MASQUE → WireGuard clean restart remains unchanged.
- Test T 700 ms MASQUE action debounce remains unchanged.
- WireGuard path and separate WireGuard/MASQUE registrations remain unchanged.
