package com.iknalos.warpgo

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.File

object MasqueManager {
    private const val DIAGNOSTIC_FILE = "masque_testg_stage.txt"

    fun isUp(): Boolean = try {
        MasqueCore.nativeIsRunning()
    } catch (_: Throwable) {
        false
    }

    fun lastDiagnostic(context: Context): String {
        return try {
            File(context.filesDir, DIAGNOSTIC_FILE).takeIf { it.exists() }
                ?.readText()?.trim().orEmpty()
        } catch (_: Throwable) { "" }
    }

    suspend fun connect(context: Context) {
        withContext(Dispatchers.IO) {
            try { File(context.filesDir, DIAGNOSTIC_FILE).delete() } catch (_: Throwable) {}
        }

        MasqueVpnService.start(context.applicationContext)

        // Fresh registration plus QUIC/H3/CONNECT-IP can take longer than the old
        // CONNECT probe. Keep the Activity responsive while the service starts.
        repeat(600) {
            if (isUp()) return
            val stage = lastDiagnostic(context)
            if (stage.startsWith("ERROR:")) {
                throw IllegalStateException(stage.removePrefix("ERROR:").trim())
            }
            delay(100)
        }

        val stage = lastDiagnostic(context)
        val nativeError = try { MasqueCore.nativeLastError() } catch (_: Throwable) { "" }
        disconnectAndAwait(context.applicationContext)
        throw IllegalStateException(
            when {
                nativeError.isNotBlank() && stage.isNotBlank() -> "$nativeError · $stage"
                nativeError.isNotBlank() -> nativeError
                stage.isNotBlank() -> "MASQUE Test G timed out after [$stage]"
                else -> "MASQUE Test G full-tunnel startup timed out"
            }
        )
    }

    fun disconnect(context: Context) {
        disconnectAndAwait(context.applicationContext)
    }

    /**
     * VPN ownership handoff only. MASQUE identity/state remains completely separate
     * from WireGuard's registration and configuration.
     */
    fun disconnectAndAwait(context: Context) {
        try { MasqueVpnService.stop(context.applicationContext) } catch (_: Throwable) {}
        repeat(120) {
            if (!isUp() && !MasqueVpnService.isServiceActive()) return
            try { Thread.sleep(25) } catch (_: InterruptedException) { return }
        }
    }

    fun prepareWireGuardHandoff(context: Context) {
        if (isUp() || MasqueVpnService.isServiceActive()) {
            disconnectAndAwait(context.applicationContext)
        }
    }
}
