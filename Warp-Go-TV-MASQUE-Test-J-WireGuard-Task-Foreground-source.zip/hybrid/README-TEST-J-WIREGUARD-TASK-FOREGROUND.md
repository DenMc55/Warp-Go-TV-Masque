# Test J — WireGuard task foreground fix

Baseline: the user-supplied **Test I UI + WireGuard Fix** source.

Purpose: fix the remaining symptom where connecting WireGuard returns the user to the Fire TV launcher / appears to close Warp Go TV.

Changes only:
- Keep the Test I UI unchanged.
- Keep the Test I MASQUE transport unchanged.
- Keep the existing WireGuard tunnel/configuration path unchanged.
- Add `android.permission.REORDER_TASKS`.
- After a successful WireGuard connect, move the existing Warp Go task to the foreground immediately, then again at 350 ms and 1000 ms to survive the Fire OS VPN handoff.
- Fall back to bringing the existing `singleTask` MainActivity to the front if `moveTaskToFront()` is rejected.
- ARM64/newer-device branch only; no Fire TV Stick 4K 1st-gen/legacy compatibility work is added.

This test deliberately does **not** change MASQUE behaviour or the Test I screen layout.
