package com.iknalos.warpgo

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.IBinder
import android.os.ParcelFileDescriptor
import androidx.core.app.NotificationCompat

class MasqueVpnService : VpnService() {
    private var pfd: ParcelFileDescriptor? = null
    @Volatile private var shuttingDown = false
    @Volatile private var starting = false

    companion object {
        private const val CHANNEL = "warp_go_masque"
        private const val NOTIFICATION_ID = 4510
        private const val ACTION_START = "com.iknalos.warpgo.MASQUE_START"
        private const val ACTION_STOP = "com.iknalos.warpgo.MASQUE_STOP"
        @Volatile private var instance: MasqueVpnService? = null

        init { System.loadLibrary("warpmasque") }

        @JvmStatic private external fun nativePrepare(filesDir: String): String
        @JvmStatic private external fun nativeStart(filesDir: String, fd: Int): String
        @JvmStatic private external fun nativeStop()

        @JvmStatic fun protectSocket(fd: Int): Boolean = try {
            instance?.protect(fd) ?: false
        } catch (_: Throwable) { false }

        fun isServiceActive(): Boolean = instance != null

        fun start(context: Context) {
            val i = Intent(context, MasqueVpnService::class.java).setAction(ACTION_START)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(i)
            else context.startService(i)
        }

        fun stop(context: Context) {
            val i = Intent(context, MasqueVpnService::class.java).setAction(ACTION_STOP)
            try { context.startService(i) } catch (_: Throwable) {
                try { instance?.shutdownForHandoff() } catch (_: Throwable) {}
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        createChannel()
        // A previous service instance may have died after the Java side lost its
        // reference but before the native core released every socket/TUN resource.
        // Clean only native runtime state. Registration remains untouched.
        try { nativeStop() } catch (_: Throwable) {}
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            shutdownForHandoff()
            return START_NOT_STICKY
        }

        startForeground(NOTIFICATION_ID, notification("Starting MASQUE full tunnel on UDP 443…"))
        if (starting || pfd != null || MasqueCore.nativeIsRunning()) return START_NOT_STICKY
        starting = true
        shuttingDown = false

        Thread {
            try {
                val prepared = try { nativePrepare(filesDir.absolutePath) }
                catch (t: Throwable) { "ERROR: ${t.message ?: t.javaClass.simpleName}" }
                if (!prepared.startsWith("OK:")) {
                    shutdownForHandoff()
                    return@Thread
                }

                val addresses = prepared.removePrefix("OK:").split("|", limit = 2)
                val v4 = parseAddress(addresses.getOrNull(0).orEmpty(), 32)
                val v6 = parseAddress(addresses.getOrNull(1).orEmpty(), 128)
                if (v4.first.isBlank() && v6.first.isBlank()) {
                    shutdownForHandoff()
                    return@Thread
                }

                val builder = Builder()
                    .setSession("Warp Go TV · MASQUE · UDP 443")
                    .setMtu(1280)
                    .setBlocking(true)

                if (v4.first.isNotBlank()) {
                    builder.addAddress(v4.first, v4.second)
                    builder.addRoute("0.0.0.0", 0)
                    builder.addDnsServer("1.1.1.1")
                    builder.addDnsServer("1.0.0.1")
                }
                if (v6.first.isNotBlank()) {
                    builder.addAddress(v6.first, v6.second)
                    builder.addRoute("::", 0)
                    builder.addDnsServer("2606:4700:4700::1111")
                    builder.addDnsServer("2606:4700:4700::1001")
                }

                val established = try { builder.establish() } catch (_: Throwable) { null }
                if (established == null) {
                    shutdownForHandoff()
                    return@Thread
                }
                pfd = established
                val fd = established.detachFd()
                pfd = null

                val result = try { nativeStart(filesDir.absolutePath, fd) }
                catch (t: Throwable) { "ERROR: ${t.message ?: t.javaClass.simpleName}" }
                if (result.startsWith("OK:")) {
                    getSystemService(NotificationManager::class.java).notify(
                        NOTIFICATION_ID,
                        notification("MASQUE full tunnel active · UDP 443 · Test L")
                    )
                } else {
                    shutdownForHandoff()
                }
            } finally {
                starting = false
            }
        }.start()

        return START_NOT_STICKY
    }

    private fun parseAddress(value: String, fallbackPrefix: Int): Pair<String, Int> {
        val trimmed = value.trim()
        if (trimmed.isBlank() || trimmed.startsWith("/")) return "" to fallbackPrefix
        val slash = trimmed.lastIndexOf('/')
        if (slash <= 0) return trimmed to fallbackPrefix
        val host = trimmed.substring(0, slash)
        val prefix = trimmed.substring(slash + 1).toIntOrNull() ?: fallbackPrefix
        return host to prefix
    }

    @Synchronized
    private fun shutdownForHandoff() {
        if (shuttingDown) return
        shuttingDown = true
        try { nativeStop() } catch (_: Throwable) {}
        try { pfd?.close() } catch (_: Throwable) {}
        pfd = null
        try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (_: Throwable) {}
        stopSelf()
        // Do NOT clear instance here. onDestroy is the authoritative point at
        // which a second service instance is safe to start.
    }

    override fun onRevoke() {
        shutdownForHandoff()
        super.onRevoke()
    }

    override fun onDestroy() {
        try { nativeStop() } catch (_: Throwable) {}
        try { pfd?.close() } catch (_: Throwable) {}
        pfd = null
        if (instance === this) instance = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = super.onBind(intent)

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(CHANNEL, "Warp Go TV MASQUE", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    private fun notification(text: String) = NotificationCompat.Builder(this, CHANNEL)
        .setSmallIcon(android.R.drawable.stat_sys_download_done)
        .setContentTitle("Warp Go TV")
        .setContentText(text)
        .setOngoing(true)
        .setPriority(NotificationCompat.PRIORITY_LOW)
        .setContentIntent(
            PendingIntent.getActivity(
                this, 0, Intent(this, MainActivity::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        )
        .build()
}
