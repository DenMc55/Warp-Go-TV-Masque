package com.iknalos.warpgo

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.File

object MasqueManager {
    private const val DIAGNOSTIC_FILE = "masque_testi_stage.txt"

    fun isUp(): Boolean = try { MasqueCore.nativeIsRunning() } catch (_: Throwable) { false }

    fun lastDiagnostic(context: Context): String = try {
        File(context.filesDir, DIAGNOSTIC_FILE).takeIf { it.exists() }?.readText()?.trim().orEmpty()
    } catch (_: Throwable) { "" }

    suspend fun connect(context: Context) {
        val app = context.applicationContext
        // Test L: every connect begins from a fully stopped runtime/service, but
        // does NOT erase masque_clean_reg.json. The MASQUE account remains its own sandbox.
        disconnectAndAwait(app)
        withContext(Dispatchers.IO) {
            try { File(app.filesDir, DIAGNOSTIC_FILE).delete() } catch (_: Throwable) {}
        }
        MasqueVpnService.start(app)

        repeat(600) {
            if (isUp()) return
            val stage = lastDiagnostic(app)
            if (stage.startsWith("ERROR:")) {
                disconnectAndAwait(app)
                throw IllegalStateException(stage.removePrefix("ERROR:").trim())
            }
            delay(100)
        }

        val stage = lastDiagnostic(app)
        val nativeError = try { MasqueCore.nativeLastError() } catch (_: Throwable) { "" }
        disconnectAndAwait(app)
        throw IllegalStateException(
            when {
                nativeError.isNotBlank() && stage.isNotBlank() -> "$nativeError · $stage"
                nativeError.isNotBlank() -> nativeError
                stage.isNotBlank() -> "MASQUE Test L timed out after [$stage]"
                else -> "MASQUE Test L full-tunnel startup timed out"
            }
        )
    }

    fun disconnect(context: Context) = disconnectAndAwait(context.applicationContext)

    fun disconnectAndAwait(context: Context) {
        val app = context.applicationContext
        try { MasqueVpnService.stop(app) } catch (_: Throwable) {}
        // Wait for BOTH native runtime and Android service destruction. Keeping
        // instance non-null until onDestroy prevents connect #2 racing connect #1 teardown.
        repeat(200) {
            if (!isUp() && !MasqueVpnService.isServiceActive()) return
            try { Thread.sleep(25) } catch (_: InterruptedException) { return }
        }
        // Final native state is harmless to clear; registration file is not touched.
        try { Thread.sleep(100) } catch (_: InterruptedException) {}
    }

    fun prepareWireGuardHandoff(context: Context) {
        if (isUp() || MasqueVpnService.isServiceActive()) disconnectAndAwait(context.applicationContext)
    }
}
