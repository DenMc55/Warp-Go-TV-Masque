# Test L — lifecycle + MASQUE reconnect isolation

Baseline: Test I UI. Test K task-reordering changes are NOT carried forward.

Changes under test:
- WireGuard and MASQUE identities remain separate (`warp_reg` vs `masque_clean_reg.json`).
- MainActivity no longer relaunches/reorders itself after WireGuard connects.
- MainActivity uses normal `singleTop` task behaviour and records pause/stop/destroy events.
- MASQUE service uses explicit START/STOP actions and `START_NOT_STICKY`.
- MASQUE service remains "active" until `onDestroy`, preventing a second connect racing teardown.
- Every MASQUE connect starts from a stopped runtime but reuses its own saved MASQUE registration.
- Native teardown marks runtime stopped first and closes TUN/UDP before higher-level H3 objects.

Test sequence:
1. WireGuard connect/disconnect twice; note whether UI stays open.
2. MASQUE connect, browse/test traffic, disconnect, then connect again.
3. Switch MASQUE -> WireGuard -> MASQUE once.
