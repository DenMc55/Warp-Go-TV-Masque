# Test R – Clean Protocol Relaunch

Baseline: stable Test M line.

Change: protocol changes no longer hot-swap VPN engines in one process. When the user changes WireGuard/MASQUE while disconnected, the selected protocol is saved, the previous transport is asked to stop, and MainActivity is relaunched by AlarmManager after the current app process exits. The UI returns automatically with the newly selected protocol in a fresh process.

Connected/busy protocol controls remain locked. WireGuard ports remain locked while WireGuard is active/busy.
