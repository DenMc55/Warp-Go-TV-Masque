# Test Q Diagnostic

Based on Test P/M stable line. No behavioural workaround added. Adds persistent diagnostic logging for MASQUE teardown, Activity lifecycle, VpnService.prepare, WireGuard backend creation and setState transitions, plus an uncaught-exception handler. If the first WireGuard connection after MASQUE ends unexpectedly, the next app resume displays the last recorded diagnostic event in the status line.
