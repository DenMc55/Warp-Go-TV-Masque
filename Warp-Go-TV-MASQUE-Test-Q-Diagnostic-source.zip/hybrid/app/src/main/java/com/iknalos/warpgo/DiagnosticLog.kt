package com.iknalos.warpgo

import android.content.Context
import android.util.Log
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

object DiagnosticLog {
    private const val TAG = "WarpGoDiag"
    private const val FILE = "test_q_diagnostic.log"
    private const val PREFS = "test_q_diag"
    private const val K_PENDING = "pending_first_wg_after_masque"

    @Synchronized
    fun event(context: Context, message: String) {
        val line = "${timestamp()} [${Thread.currentThread().name}] $message"
        Log.i(TAG, line)
        try {
            val f = File(context.applicationContext.filesDir, FILE)
            if (f.exists() && f.length() > 128 * 1024) f.writeText("")
            f.appendText(line + "\n")
        } catch (_: Throwable) {}
    }

    @Synchronized
    fun error(context: Context, message: String, t: Throwable? = null) {
        val detail = if (t == null) message else "$message :: ${t.javaClass.simpleName}: ${t.message ?: ""}"
        event(context, "ERROR $detail")
        if (t != null) {
            try {
                File(context.applicationContext.filesDir, FILE).appendText(
                    t.stackTraceToString().take(12000) + "\n"
                )
            } catch (_: Throwable) {}
        }
    }

    fun markFirstWireGuardPending(context: Context, pending: Boolean) {
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putBoolean(K_PENDING, pending).commit()
        event(context, "first-WG-after-MASQUE pending=$pending")
    }

    fun firstWireGuardPending(context: Context): Boolean =
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getBoolean(K_PENDING, false)

    fun lastEvent(context: Context): String {
        return try {
            File(context.applicationContext.filesDir, FILE)
                .takeIf { it.exists() }
                ?.readLines()
                ?.lastOrNull { it.isNotBlank() }
                ?.take(180)
                .orEmpty()
        } catch (_: Throwable) { "" }
    }

    private fun timestamp(): String {
        val sdf = SimpleDateFormat("HH:mm:ss.SSS", Locale.UK)
        sdf.timeZone = TimeZone.getDefault()
        return sdf.format(Date())
    }
}
