package com.iknalos.warpgo

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.IBinder
import android.os.ParcelFileDescriptor
import androidx.core.app.NotificationCompat

class MasqueVpnService : VpnService() {
    private var pfd: ParcelFileDescriptor? = null
    @Volatile private var shuttingDown = false

    companion object {
        private const val CHANNEL = "warp_go_masque"
        private const val NOTIFICATION_ID = 4510
        @Volatile private var instance: MasqueVpnService? = null

        init { System.loadLibrary("masquegraft") }

        @JvmStatic private external fun nativeStart(filesDir: String, fd: Int): String
        @JvmStatic private external fun nativeStop()

        @JvmStatic fun protectSocket(fd: Int): Boolean = try {
            instance?.protect(fd) ?: false
        } catch (_: Throwable) { false }

        fun isServiceActive(): Boolean = instance != null

        fun start(context: Context) {
            val i = Intent(context, MasqueVpnService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(i)
            else context.startService(i)
        }

        /**
         * Test F handoff: release native QUIC/H3 state and the diagnostic TUN
         * synchronously before Android is asked to stop the service. This avoids
         * leaving MASQUE-owned VPN/socket state alive while WireGuard takes over.
         */
        fun stop(context: Context) {
            instance?.shutdownForHandoff()
            context.stopService(Intent(context, MasqueVpnService::class.java))
        }
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIFICATION_ID, notification("Starting MASQUE Test F…"))
        if (pfd != null || MasqueGraft.nativeIsRunning()) return START_STICKY

        val builder = Builder()
            .setSession("Warp Go TV · MASQUE")
            .setMtu(1400)
            .setBlocking(true)
            .addAddress("172.16.0.2", 32)
            .addRoute("198.18.0.0", 15)

        val established = try { builder.establish() } catch (_: Throwable) { null }
        if (established == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        pfd = established
        val fd = established.detachFd()

        Thread {
            val result = try { nativeStart(filesDir.absolutePath, fd) }
            catch (t: Throwable) { "ERROR: ${t.message ?: t.javaClass.simpleName}" }
            if (result.startsWith("OK:")) {
                val nm = getSystemService(NotificationManager::class.java)
                nm.notify(NOTIFICATION_ID, notification("MASQUE core + CONNECT probe ready · Test F"))
            } else {
                shutdownForHandoff()
            }
        }.start()

        return START_STICKY
    }

    @Synchronized
    private fun shutdownForHandoff() {
        if (shuttingDown) return
        shuttingDown = true
        try { nativeStop() } catch (_: Throwable) {}
        try { pfd?.close() } catch (_: Throwable) {}
        pfd = null
        try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (_: Throwable) {}
        try { stopSelf() } catch (_: Throwable) {}
        if (instance === this) instance = null
    }

    override fun onRevoke() {
        shutdownForHandoff()
        super.onRevoke()
    }

    override fun onDestroy() {
        shutdownForHandoff()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = super.onBind(intent)

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(CHANNEL, "Warp Go TV MASQUE", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    private fun notification(text: String) = NotificationCompat.Builder(this, CHANNEL)
        .setSmallIcon(android.R.drawable.stat_sys_download_done)
        .setContentTitle("Warp Go TV")
        .setContentText(text)
        .setOngoing(true)
        .setPriority(NotificationCompat.PRIORITY_LOW)
        .setContentIntent(
            PendingIntent.getActivity(
                this, 0, Intent(this, MainActivity::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        )
        .build()
}
