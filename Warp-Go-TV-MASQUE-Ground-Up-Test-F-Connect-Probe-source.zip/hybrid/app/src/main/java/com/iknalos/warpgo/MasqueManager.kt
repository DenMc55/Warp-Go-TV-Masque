package com.iknalos.warpgo

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.File

object MasqueManager {
    private const val DIAGNOSTIC_FILE = "masque_teste_stage.txt"

    fun isUp(): Boolean = try {
        MasqueGraft.nativeIsRunning()
    } catch (_: Throwable) {
        false
    }

    fun lastDiagnostic(context: Context): String {
        return try {
            File(context.filesDir, DIAGNOSTIC_FILE).takeIf { it.exists() }
                ?.readText()?.trim().orEmpty()
        } catch (_: Throwable) { "" }
    }

    suspend fun connect(context: Context) {
        withContext(Dispatchers.IO) {
            try { File(context.filesDir, DIAGNOSTIC_FILE).delete() } catch (_: Throwable) {}
        }

        MasqueVpnService.start(context.applicationContext)

        repeat(160) {
            if (isUp()) return
            val stage = lastDiagnostic(context)
            if (stage.startsWith("ERROR:")) {
                throw IllegalStateException(stage.removePrefix("ERROR:").trim())
            }
            delay(100)
        }

        val stage = lastDiagnostic(context)
        val nativeError = try { MasqueGraft.nativeLastError() } catch (_: Throwable) { "" }
        disconnectAndAwait(context.applicationContext)
        throw IllegalStateException(
            when {
                nativeError.isNotBlank() && stage.isNotBlank() -> "$nativeError · $stage"
                nativeError.isNotBlank() -> nativeError
                stage.isNotBlank() -> "MASQUE Test F timed out after [$stage]"
                else -> "MASQUE Test F service/core startup timed out"
            }
        )
    }

    fun disconnect(context: Context) {
        disconnectAndAwait(context.applicationContext)
    }

    /**
     * Synchronous handoff barrier. The old service can take a short time to be
     * destroyed by Android even after stopService(). Test F waits until both the
     * native core and service instance are gone before WireGuard is allowed to start.
     */
    fun disconnectAndAwait(context: Context) {
        try { MasqueVpnService.stop(context.applicationContext) } catch (_: Throwable) {}
        repeat(80) {
            if (!isUp() && !MasqueVpnService.isServiceActive()) return
            try { Thread.sleep(25) } catch (_: InterruptedException) { return }
        }
    }

    fun prepareWireGuardHandoff(context: Context) {
        if (isUp() || MasqueVpnService.isServiceActive()) {
            disconnectAndAwait(context.applicationContext)
        }
    }
}
