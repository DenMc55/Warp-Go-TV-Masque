package com.iknalos.warpgo

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.VpnService
import android.os.Bundle
import android.text.SpannableString
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.view.View
import android.widget.Button
import android.widget.ProgressBar
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.material.materialswitch.MaterialSwitch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout

class MainActivity : AppCompatActivity() {

    private var busy = false
    private var isTvMode = true
    private var suppressProtocolChange = false
    private var activeProtocolSelection = AppPreferences.PROTOCOL_WIREGUARD

    private lateinit var statusText: TextView
    private lateinit var progress: ProgressBar
    private lateinit var toggleButton: Button
    private lateinit var portGroup: RadioGroup
    private lateinit var port4500: RadioButton
    private lateinit var port2408: RadioButton
    private lateinit var port500: RadioButton
    private lateinit var portSectionTitle: TextView
    private lateinit var portSectionHelp: TextView
    private lateinit var portSwitchNote: TextView
    private lateinit var autoConnectSwitch: MaterialSwitch
    private lateinit var resetButton: Button
    private lateinit var protocolGroup: RadioGroup
    private lateinit var protocolWireGuard: RadioButton
    private lateinit var protocolMasque: RadioButton

    private val vpnPermission =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) {
                doConnect()
            } else {
                setStatus("VPN permission denied", StatusState.ERROR)
                setBusy(false)
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (!AppPreferences.hasUiMode(this)) {
            showFirstRunSetup()
            return
        }

        showSelectedInterface()
    }

    override fun onResume() {
        super.onResume()
        if (::toggleButton.isInitialized) {
            refreshState()
            if (isTvMode) focusToggleButton()
            // Second-chance restore: if Android/Fire OS blocked the background
            // boot attempt, opening Warp Go gives the desired ON state another
            // chance without showing the VPN permission dialog.
            maybeRestoreDesiredState()
        }
    }

    private fun showFirstRunSetup() {
        setContentView(R.layout.activity_setup)

        val modeGroup = findViewById<RadioGroup>(R.id.modeGroup)
        val modeTv = findViewById<RadioButton>(R.id.modeTv)
        val modeMobile = findViewById<RadioButton>(R.id.modeMobile)
        val okButton = findViewById<Button>(R.id.modeOkButton)

        // Deliberately default to TV. On a television the mobile layout can look
        // usable while hiding TV-only controls below the fold; the reverse is obvious.
        modeTv.isChecked = true
        modeTv.requestFocus()

        okButton.setOnClickListener {
            val mode = if (modeGroup.checkedRadioButtonId == modeMobile.id) {
                AppPreferences.MODE_MOBILE
            } else {
                AppPreferences.MODE_TV
            }
            AppPreferences.setUiMode(this, mode)
            showSelectedInterface()
        }
    }

    private fun showSelectedInterface() {
        isTvMode = AppPreferences.uiMode(this) == AppPreferences.MODE_TV
        setContentView(if (isTvMode) R.layout.activity_tv else R.layout.activity_mobile)
        bindMainViews()
        wireMainControls()
        restorePreferences()
        refreshState()
        if (isTvMode) focusToggleButton()
    }

    private fun bindMainViews() {
        statusText = findViewById(R.id.statusText)
        progress = findViewById(R.id.progress)
        toggleButton = findViewById(R.id.toggleButton)
        portGroup = findViewById(R.id.portGroup)
        port4500 = findViewById(R.id.port4500)
        port2408 = findViewById(R.id.port2408)
        port500 = findViewById(R.id.port500)
        portSectionTitle = findViewById(R.id.portSectionTitle)
        portSectionHelp = findViewById(R.id.portSectionHelp)
        portSwitchNote = findViewById(R.id.portSwitchNote)
        autoConnectSwitch = findViewById(R.id.autoConnectSwitch)
        resetButton = findViewById(R.id.resetButton)
        protocolGroup = findViewById(R.id.protocolGroup)
        protocolWireGuard = findViewById(R.id.protocolWireGuard)
        protocolMasque = findViewById(R.id.protocolMasque)
    }

    private fun wireMainControls() {
        toggleButton.setOnClickListener { onToggle() }
        portGroup.setOnCheckedChangeListener { _, _ ->
            AppPreferences.setSelectedPort(this, selectedPort())
        }
        autoConnectSwitch.setOnCheckedChangeListener { _, checked ->
            AppPreferences.setAutoConnectOnBoot(this, checked)
        }
        resetButton.setOnClickListener {
            WarpManager.resetRegistration(this)
            setStatus("Registration cleared", StatusState.DISCONNECTED)
        }

        protocolGroup.setOnCheckedChangeListener { _, checkedId ->
            if (suppressProtocolChange) return@setOnCheckedChangeListener

            val protocol = if (checkedId == protocolMasque.id) {
                AppPreferences.PROTOCOL_MASQUE
            } else {
                AppPreferences.PROTOCOL_WIREGUARD
            }
            val previousProtocol = activeProtocolSelection
            if (protocol == previousProtocol) return@setOnCheckedChangeListener

            AppPreferences.setSelectedProtocol(this, protocol)
            activeProtocolSelection = protocol
            updatePortSectionVisibility()
            beginProtocolHandover(previousProtocol, protocol)
        }

        if (isTvMode) {
            toggleButton.setOnFocusChangeListener { _, hasFocus ->
                updateToggleFocusStyle(hasFocus)
            }
        }
    }

    private fun restorePreferences() {
        when (AppPreferences.selectedPort(this)) {
            2408 -> port2408.isChecked = true
            500 -> port500.isChecked = true
            else -> port4500.isChecked = true
        }
        autoConnectSwitch.isChecked = AppPreferences.autoConnectOnBoot(this)
        val savedProtocol = AppPreferences.selectedProtocol(this)
        activeProtocolSelection = savedProtocol
        suppressProtocolChange = true
        if (savedProtocol == AppPreferences.PROTOCOL_MASQUE) {
            protocolMasque.isChecked = true
        } else {
            protocolWireGuard.isChecked = true
        }
        suppressProtocolChange = false
        updatePortSectionVisibility()
    }

    private fun updatePortSectionVisibility() {
        val show = selectedProtocol() == AppPreferences.PROTOCOL_WIREGUARD
        val visibility = if (show) View.VISIBLE else View.GONE
        portSectionTitle.visibility = visibility
        portSectionHelp.visibility = visibility
        portGroup.visibility = visibility
        portSwitchNote.visibility = visibility
    }

    private fun refreshState() {
        // Ground-up Test B: keep the WireGuard UI path isolated from the
        // MASQUE native runtime. This mirrors the proven Warp Go 1.5 lifecycle
        // whenever WireGuard is selected.
        if (selectedProtocol() == AppPreferences.PROTOCOL_WIREGUARD) {
            val up = WarpManager.isUp(this)
            toggleButton.text = getString(if (up) R.string.disconnect else R.string.connect)
            if (up) {
                setStatus("Connected  ·  WireGuard  ·  port ${selectedPort()}", StatusState.CONNECTED)
            } else {
                setStatus("Disconnected  ·  WireGuard", StatusState.DISCONNECTED)
            }
        } else {
            val up = MasqueManager.isUp()
            toggleButton.text = getString(if (up) R.string.disconnect else R.string.connect)
            if (up) {
                setStatus("MASQUE full tunnel  ·  UDP 443  ·  Test I", StatusState.CONNECTED)
            } else {
                val stage = MasqueManager.lastDiagnostic(this)
                if (stage.isNotBlank() && !stage.startsWith("14 ")) {
                    setStatus("MASQUE Test I  ·  $stage", StatusState.DISCONNECTED)
                } else {
                    setStatus("Disconnected  ·  MASQUE", StatusState.DISCONNECTED)
                }
            }
        }
        updatePortSectionVisibility()
        updateProtocolControls()
        updatePortControls()
    }


    private fun beginProtocolHandover(previousProtocol: String, newProtocol: String) {
        if (busy) return

        setBusy(true)
        val newLabel = if (newProtocol == AppPreferences.PROTOCOL_MASQUE) "MASQUE" else "WireGuard"
        setStatus("Switching to $newLabel…", StatusState.CONNECTING)

        lifecycleScope.launch {
            try {
                // Tear down only the transport we are leaving. Keep the proven v1.5
                // WireGuard connect path itself completely unchanged.
                withContext(Dispatchers.IO) {
                    if (previousProtocol == AppPreferences.PROTOCOL_MASQUE) {
                        if (MasqueManager.isUp()) {
                            MasqueManager.disconnect(applicationContext)
                        }
                    } else {
                        if (WarpManager.isUp(applicationContext)) {
                            WarpManager.disconnect(applicationContext)
                        }
                    }
                }

                // MASQUE -> WireGuard is the sensitive handover seen in Test L.
                // Do not enable WireGuard merely because a fixed delay elapsed: first
                // confirm that both the MASQUE native core and its VpnService are down.
                if (previousProtocol == AppPreferences.PROTOCOL_MASQUE &&
                    newProtocol == AppPreferences.PROTOCOL_WIREGUARD) {
                    val masqueDown = awaitMasqueFullyDown()
                    if (!masqueDown) {
                        setStatus("MASQUE shutdown timed out  ·  WireGuard not started", StatusState.ERROR)
                        return@launch
                    }
                    // Small final guard for Android/Fire OS to release VPN ownership
                    // after the service/native state has gone down.
                    delay(MASQUE_TO_WIREGUARD_RELEASE_MS)
                } else {
                    // Keep the Test J/L behaviour unchanged for WireGuard -> MASQUE.
                    delay(PROTOCOL_HANDOVER_SETTLE_MS)
                }
            } catch (e: Throwable) {
                setStatus("Protocol switch warning: ${e.message ?: "unknown error"}", StatusState.ERROR)
            } finally {
                setBusy(false)
                refreshState()
                if (isTvMode) focusToggleButton()
            }
        }
    }

    private fun selectedProtocol(): String =
        if (protocolGroup.checkedRadioButtonId == protocolMasque.id) AppPreferences.PROTOCOL_MASQUE
        else AppPreferences.PROTOCOL_WIREGUARD

    private fun selectedProtocolLabel(): String =
        if (selectedProtocol() == AppPreferences.PROTOCOL_MASQUE) "MASQUE" else "WireGuard"

    private fun selectedTunnelUp(): Boolean =
        if (selectedProtocol() == AppPreferences.PROTOCOL_MASQUE) MasqueManager.isUp()
        else WarpManager.isUp(this)

    private fun selectedPort(): Int = when (portGroup.checkedRadioButtonId) {
        port4500.id -> 4500
        port500.id -> 500
        else -> 2408
    }

    private fun onToggle() {
        if (busy) return
        if (selectedTunnelUp()) {
            // Remember the user's explicit choice, independently of the
            // Auto-connect switch.
            AppPreferences.setLastManualConnected(this, false)
            disconnect()
        } else {
            AppPreferences.setLastManualConnected(this, true)
            setBusy(true)
            setStatus("Connecting…", StatusState.CONNECTING)
            val intent = VpnService.prepare(this)
            if (intent != null) {
                vpnPermission.launch(intent)
            } else {
                doConnect()
            }
        }
    }


    private fun maybeRestoreDesiredState() {
        if (busy) return
        if (!AppPreferences.shouldRestoreConnectedState(this)) return
        if (AppPreferences.selectedProtocol(this) != AppPreferences.PROTOCOL_WIREGUARD) return
        if (!WarpManager.isRegistered(this)) return
        if (WarpManager.isUp(this)) return
        if (!hasUsableNetwork()) return

        // Never launch the Android VPN permission UI automatically. One manual
        // connection must have granted permission previously.
        if (VpnService.prepare(this) != null) return

        setBusy(true)
        setStatus("Restoring connection…", StatusState.CONNECTING)
        val port = AppPreferences.selectedPort(this)
        lifecycleScope.launch {
            try {
                withContext(Dispatchers.IO) {
                    WarpManager.connect(applicationContext, port)
                }
                refreshState()
            } catch (_: Exception) {
                // Leave the app usable. The boot foreground service has its own
                // retry loop; this path is deliberately just an extra chance.
                refreshState()
            } finally {
                setBusy(false)
                refreshButtonOnly()
                if (isTvMode) focusToggleButton()
            }
        }
    }

    private fun hasUsableNetwork(): Boolean {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(network) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    private fun doConnect() {
        val protocol = selectedProtocol()
        val port = selectedPort()
        AppPreferences.setSelectedPort(this, port)
        AppPreferences.setSelectedProtocol(this, protocol)
        lifecycleScope.launch {
            try {
                withTimeout(CONNECT_TIMEOUT_MS) {
                    if (protocol == AppPreferences.PROTOCOL_MASQUE) {
                        withContext(Dispatchers.IO) {
                            if (WarpManager.isUp(applicationContext)) WarpManager.disconnect(applicationContext)
                            MasqueManager.connect(applicationContext)
                        }
                    } else {
                        // Keep WireGuard's connection lifecycle identical to the proven
                        // Warp Go TV v1.5 path. MASQUE is a separate selectable transport and
                        // must not participate in WireGuard connect/disconnect.
                        withContext(Dispatchers.IO) {
                            WarpManager.connect(applicationContext, port)
                        }
                    }
                }

                if (protocol == AppPreferences.PROTOCOL_MASQUE) {
                    setStatus("MASQUE full tunnel  ·  UDP 443  ·  Test I", StatusState.CONNECTED)
                } else {
                    setStatus("Connected  ·  WireGuard  ·  port $port", StatusState.CONNECTED)
                }
            } catch (_: TimeoutCancellationException) {
                // A half-started VpnService can otherwise make the next protocol change
                // unreliable. Clean up the timed-out transport before returning control.
                withContext(NonCancellable + Dispatchers.IO) {
                    if (protocol == AppPreferences.PROTOCOL_MASQUE) {
                        MasqueManager.disconnect(applicationContext)
                    } else if (WarpManager.isUp(applicationContext)) {
                        WarpManager.disconnect(applicationContext)
                    }
                }
                setStatus("Connection timed out  ·  ${if (protocol == AppPreferences.PROTOCOL_MASQUE) "MASQUE" else "WireGuard"}", StatusState.ERROR)
            } catch (e: Throwable) {
                // Treat an ordinary failed start the same way as a timeout: do not leave
                // a partially started service owning VPN state for the next attempt.
                withContext(NonCancellable + Dispatchers.IO) {
                    if (protocol == AppPreferences.PROTOCOL_MASQUE) {
                        MasqueManager.disconnect(applicationContext)
                    } else if (WarpManager.isUp(applicationContext)) {
                        WarpManager.disconnect(applicationContext)
                    }
                }
                setStatus("Failed: ${e.message ?: "unknown error"}", StatusState.ERROR)
            } finally {
                setBusy(false)
                refreshState()
                if (isTvMode) focusToggleButton()
            }
        }
    }

    private fun disconnect() {
        setBusy(true)
        val protocol = selectedProtocol()
        val protocolLabel = if (protocol == AppPreferences.PROTOCOL_MASQUE) "MASQUE" else "WireGuard"
        toggleButton.text = "Disconnecting…"
        setStatus("Disconnecting  ·  $protocolLabel…", StatusState.CONNECTING)

        lifecycleScope.launch {
            try {
                if (protocol == AppPreferences.PROTOCOL_MASQUE) {
                    withContext(Dispatchers.IO) {
                        MasqueManager.disconnect(applicationContext)
                    }
                } else {
                    // Preserve the original Warp Go 1.5 WireGuard disconnect call.
                    withContext(Dispatchers.IO) {
                        WarpManager.disconnect(applicationContext)
                    }
                }

                // Android/Fire OS can finish VpnService teardown after the disconnect
                // call returns. Do not tell the UI it is down until the selected tunnel
                // actually reports down. This is intentionally Activity-side only so the
                // proven v1.5 WireGuard backend remains unchanged.
                val confirmedDown = awaitProtocolDown(protocol)
                if (confirmedDown) {
                    setStatus("Disconnected  ·  $protocolLabel", StatusState.DISCONNECTED)
                } else {
                    setStatus("Disconnect still settling  ·  $protocolLabel", StatusState.CONNECTING)
                }
            } catch (e: Exception) {
                setStatus("Error: ${e.message ?: "unknown error"}", StatusState.ERROR)
            } finally {
                setBusy(false)
                refreshState()
                if (isTvMode) focusToggleButton()
            }
        }
    }


    private suspend fun awaitMasqueFullyDown(): Boolean {
        repeat(MASQUE_HANDOVER_CONFIRM_ATTEMPTS) {
            val down = withContext(Dispatchers.IO) {
                !MasqueManager.isUp() && !MasqueVpnService.isServiceActive()
            }
            if (down) return true
            delay(MASQUE_HANDOVER_CONFIRM_POLL_MS)
        }
        return withContext(Dispatchers.IO) {
            !MasqueManager.isUp() && !MasqueVpnService.isServiceActive()
        }
    }

    private suspend fun awaitProtocolDown(protocol: String): Boolean {
        repeat(DISCONNECT_CONFIRM_ATTEMPTS) {
            val down = withContext(Dispatchers.IO) {
                if (protocol == AppPreferences.PROTOCOL_MASQUE) {
                    !MasqueManager.isUp() && !MasqueVpnService.isServiceActive()
                } else {
                    !WarpManager.isUp(applicationContext)
                }
            }
            if (down) return true
            delay(DISCONNECT_CONFIRM_POLL_MS)
        }

        return withContext(Dispatchers.IO) {
            if (protocol == AppPreferences.PROTOCOL_MASQUE) {
                !MasqueManager.isUp() && !MasqueVpnService.isServiceActive()
            } else {
                !WarpManager.isUp(applicationContext)
            }
        }
    }

    private fun refreshButtonOnly() {
        toggleButton.text = getString(
            if (selectedTunnelUp()) R.string.disconnect else R.string.connect
        )
        updateProtocolControls()
        updatePortControls()
    }

    private fun updateProtocolControls() {
        // Do not allow protocol switching while the selected tunnel is active.
        // This avoids tearing down one VpnService while another is being selected.
        val enabled = !selectedTunnelUp() && !busy
        protocolWireGuard.isEnabled = enabled
        protocolMasque.isEnabled = enabled
    }

    private fun updatePortControls() {
        // A running WireGuard tunnel keeps the port it was created with. Prevent the
        // UI from showing a different port until that tunnel is fully disconnected.
        val enabled = selectedProtocol() == AppPreferences.PROTOCOL_WIREGUARD &&
            !busy && !WarpManager.isUp(this)
        portGroup.isEnabled = enabled
        port4500.isEnabled = enabled
        port2408.isEnabled = enabled
        port500.isEnabled = enabled
    }

    private fun setBusy(value: Boolean) {
        busy = value
        // Do not disable the main button in TV mode: disabling a focused view
        // makes Fire TV immediately move focus to another control.
        toggleButton.isEnabled = true
        progress.visibility = if (value) View.VISIBLE else View.GONE
        if (::protocolWireGuard.isInitialized) {
            protocolWireGuard.isEnabled = !value && !selectedTunnelUp()
            protocolMasque.isEnabled = !value && !selectedTunnelUp()
        }
        if (::portGroup.isInitialized) updatePortControls()
    }

    private fun focusToggleButton() {
        toggleButton.postDelayed({
            toggleButton.requestFocus()
            updateToggleFocusStyle(true)
        }, 250L)
    }

    private fun updateToggleFocusStyle(hasFocus: Boolean) {
        val color = getColor(if (hasFocus) R.color.focus_yellow else R.color.warp_orange)
        toggleButton.backgroundTintList = ColorStateList.valueOf(color)
        toggleButton.setTextColor(
            getColor(if (hasFocus) R.color.focus_text_dark else R.color.text_primary)
        )
    }

    private fun setStatus(text: String, state: StatusState) {
        val dotColor = when (state) {
            StatusState.CONNECTED -> getColor(R.color.status_green)
            StatusState.CONNECTING -> getColor(R.color.status_amber)
            StatusState.DISCONNECTED, StatusState.ERROR -> getColor(R.color.status_red)
        }
        val display = SpannableString("●  $text")
        display.setSpan(
            ForegroundColorSpan(dotColor),
            0,
            1,
            Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
        )
        statusText.text = display
        statusText.setTextColor(Color.WHITE)
    }

    companion object {
        private const val PROTOCOL_HANDOVER_SETTLE_MS = 1800L
        private const val MASQUE_TO_WIREGUARD_RELEASE_MS = 1800L
        private const val MASQUE_HANDOVER_CONFIRM_POLL_MS = 100L
        private const val MASQUE_HANDOVER_CONFIRM_ATTEMPTS = 50
        private const val DISCONNECT_CONFIRM_POLL_MS = 100L
        private const val DISCONNECT_CONFIRM_ATTEMPTS = 50
        private const val CONNECT_TIMEOUT_MS = 10_000L
    }

    private enum class StatusState {
        CONNECTED,
        CONNECTING,
        DISCONNECTED,
        ERROR
    }
}
