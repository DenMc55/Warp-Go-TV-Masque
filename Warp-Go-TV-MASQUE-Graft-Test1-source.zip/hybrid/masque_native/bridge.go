//go:build android && cgo
package main
/*
#include <jni.h>
#include <stdlib.h>
static const char* jstringToChars(JNIEnv* env, jstring j) {
    if (j == NULL) return NULL;
    return (*env)->GetStringUTFChars(env, j, NULL);
}
static void releaseChars(JNIEnv* env, jstring j, const char* chars) {
    if (j != NULL && chars != NULL) (*env)->ReleaseStringUTFChars(env, j, chars);
}
static jstring newString(JNIEnv* env, const char* s) { return (*env)->NewStringUTF(env, s); }
*/
import "C"
import (
    "context"
    "crypto/tls"
    "fmt"
    "net"
    "os"
    "path/filepath"
    "strconv"
    "time"
    "unsafe"
    "graftmasque/registration"
    "graftmasque/tunnel"
)
func resultString(env *C.JNIEnv, s string) C.jstring {
    cs := C.CString(s); defer C.free(unsafe.Pointer(cs)); return C.newString(env, cs)
}
func loadOrRegister(path string) (*registration.Registration, error) {
    if r, err := registration.Load(path); err == nil { return r, nil }
    r, err := registration.Register(); if err != nil { return nil, err }
    if err := r.Save(path); err != nil { return nil, err }; return r, nil
}
func edgeCandidates(r *registration.Registration) []string {
    ports := append([]int(nil), r.EndpointPorts...); if len(ports)==0 { ports=[]int{443} }
    ordered:=[]int{443}; for _,p:=range ports { if p!=443 { ordered=append(ordered,p) } }
    seen:=map[string]bool{}; out:=[]string{}
    for _,p:=range ordered { for _,host:=range []string{r.EndpointV4,r.EndpointV6} { if host=="" {continue}; a:=net.JoinHostPort(host,strconv.Itoa(p)); if !seen[a] { seen[a]=true; out=append(out,a) } } }
    return out
}
func buildTLS(r *registration.Registration) (*tls.Config,error) {
    verify,err:=r.PeerPublicKeyVerifier(); if err!=nil{return nil,err}
    return &tls.Config{ServerName:"consumer-masque-proxy.cloudflareclient.com",NextProtos:[]string{"h3"},InsecureSkipVerify:true,MinVersion:tls.VersionTLS13,Certificates:[]tls.Certificate{r.ClientCert},VerifyPeerCertificate:verify,CurvePreferences:[]tls.CurveID{tls.CurveP256,tls.CurveP384,tls.CurveP521}},nil
}
//export Java_com_iknalos_warpgo_MasqueGraft_nativeTest
func Java_com_iknalos_warpgo_MasqueGraft_nativeTest(env *C.JNIEnv, clazz C.jclass, filesDir C.jstring) C.jstring {
    chars:=C.jstringToChars(env,filesDir); if chars==nil{return resultString(env,"ERROR: no files directory")}
    dir:=C.GoString(chars); C.releaseChars(env,filesDir,chars)
    if err:=os.MkdirAll(dir,0700);err!=nil{return resultString(env,"ERROR: "+err.Error())}
    reg,err:=loadOrRegister(filepath.Join(dir,"masque_graft_reg.json")); if err!=nil{return resultString(env,"ERROR: MASQUE registration: "+err.Error())}
    tc,err:=buildTLS(reg); if err!=nil{return resultString(env,"ERROR: TLS: "+err.Error())}
    edges:=edgeCandidates(reg); if len(edges)==0{return resultString(env,"ERROR: no MASQUE edge")}
    ctx,cancel:=context.WithTimeout(context.Background(),30*time.Second); defer cancel()
    client,err:=tunnel.NewMasqueClientContext(ctx,edges,tc,reg.Token); if err!=nil{return resultString(env,"ERROR: MASQUE handshake: "+err.Error())}
    _=client.Close(); return resultString(env,fmt.Sprintf("MASQUE handshake OK · %d edge candidates",len(edges)))
}
func main(){}
