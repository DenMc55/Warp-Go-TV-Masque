package com.iknalos.warpgo

import android.content.Context
import android.content.Intent
import android.os.Build
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.File

object MasqueManager {
    private const val DIAGNOSTIC_FILE = "masque_testh_stage.txt"

    // Test W: do not load/query the MASQUE native library in the UI process.
    // Status comes from the isolated :masque process marker instead.
    fun isUp(context: Context): Boolean = MasqueProcessState.isRunning(context.applicationContext)

    fun isServiceActive(context: Context): Boolean =
        MasqueProcessState.isServiceActive(context.applicationContext)

    fun lastDiagnostic(context: Context): String {
        return try {
            File(context.filesDir, DIAGNOSTIC_FILE).takeIf { it.exists() }
                ?.readText()?.trim().orEmpty()
        } catch (_: Throwable) { "" }
    }

    suspend fun connect(context: Context) {
        withContext(Dispatchers.IO) {
            try { File(context.filesDir, DIAGNOSTIC_FILE).delete() } catch (_: Throwable) {}
        }

        val app = context.applicationContext
        val startIntent = Intent(app, MasqueVpnService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) app.startForegroundService(startIntent)
        else app.startService(startIntent)

        repeat(600) {
            if (isUp(context)) return
            val stage = lastDiagnostic(context)
            if (stage.startsWith("ERROR:")) {
                throw IllegalStateException(stage.removePrefix("ERROR:").trim())
            }
            delay(100)
        }

        val stage = lastDiagnostic(context)
        disconnectAndAwait(context.applicationContext)
        throw IllegalStateException(
            if (stage.isNotBlank()) "MASQUE Test I timed out after [$stage]"
            else "MASQUE Test I full-tunnel startup timed out"
        )
    }

    fun disconnect(context: Context) {
        disconnectAndAwait(context.applicationContext)
    }

    fun disconnectAndAwait(context: Context) {
        try {
            val app = context.applicationContext
            app.stopService(Intent(app, MasqueVpnService::class.java))
        } catch (_: Throwable) {}
        repeat(200) {
            if (!isUp(context) && !isServiceActive(context)) return
            try { Thread.sleep(25) } catch (_: InterruptedException) { return }
        }
    }
}
