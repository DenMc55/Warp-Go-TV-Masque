package com.iknalos.warpgo

import android.content.Context
import android.os.Process
import java.io.File

/**
 * Tiny file-backed status bridge between the main app process and the isolated
 * :masque VPN process. The marker contains STATE|PID. If the MASQUE process dies
 * natively, /proc/<pid> disappears, so stale RUNNING state is treated as down.
 */
object MasqueProcessState {
    private const val FILE_NAME = "masque_process_state.txt"

    private fun stateFile(context: Context) = File(context.filesDir, FILE_NAME)

    fun write(context: Context, state: String) {
        try {
            val target = stateFile(context)
            val tmp = File(target.parentFile, "$FILE_NAME.tmp.${Process.myPid()}")
            tmp.writeText("$state|${Process.myPid()}")
            if (!tmp.renameTo(target)) {
                target.writeText("$state|${Process.myPid()}")
                tmp.delete()
            }
        } catch (_: Throwable) {
        }
    }

    data class Snapshot(val state: String, val pid: Int) {
        fun processAlive(): Boolean = pid > 0 && try {
            File("/proc/$pid").exists()
        } catch (_: Throwable) {
            false
        }
    }

    fun read(context: Context): Snapshot {
        return try {
            val parts = stateFile(context).readText().trim().split('|', limit = 2)
            Snapshot(parts.getOrNull(0).orEmpty(), parts.getOrNull(1)?.toIntOrNull() ?: -1)
        } catch (_: Throwable) {
            Snapshot("STOPPED", -1)
        }
    }

    fun isRunning(context: Context): Boolean {
        val s = read(context)
        return s.state == "RUNNING" && s.processAlive()
    }

    fun isServiceActive(context: Context): Boolean {
        val s = read(context)
        return s.state != "STOPPED" && s.processAlive()
    }
}
