# Test W – MASQUE process isolation

Baseline: Test U.

Only architectural change: `MasqueVpnService` runs in the private `:masque` Android process.
The main UI/WireGuard process no longer loads or queries MASQUE native state directly; it reads a
small file-backed state marker containing MASQUE state and PID. If the MASQUE native process dies,
the PID disappears and the UI treats MASQUE as down.

Test S delayed MASQUE -> WireGuard restart, Test U fresh-session delay, WireGuard path, UI locking,
and separate registration stores remain unchanged.
