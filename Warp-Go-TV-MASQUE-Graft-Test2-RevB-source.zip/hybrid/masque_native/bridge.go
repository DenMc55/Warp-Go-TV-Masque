//go:build android && cgo

package main

/*
#include <jni.h>
#include <stdlib.h>

static JavaVM* g_jvm = NULL;
static jclass g_vpn_cls = NULL;
static jmethodID g_protect_mid = NULL;

static void rememberVM(JNIEnv* env) {
    if (g_jvm == NULL) (*env)->GetJavaVM(env, &g_jvm);
}
static void rememberVpnClass(JNIEnv* env, jclass cls) {
    if (g_vpn_cls == NULL) g_vpn_cls = (*env)->NewGlobalRef(env, cls);
    if (g_protect_mid == NULL && g_vpn_cls != NULL)
        g_protect_mid = (*env)->GetStaticMethodID(env, g_vpn_cls, "protectSocket", "(I)Z");
}
static JNIEnv* getEnv(int* detach) {
    *detach = 0;
    if (g_jvm == NULL) return NULL;
    JNIEnv* env = NULL;
    jint r = (*g_jvm)->GetEnv(g_jvm, (void**)&env, JNI_VERSION_1_6);
    if (r == JNI_EDETACHED) {
        if ((*g_jvm)->AttachCurrentThread(g_jvm, &env, NULL) != 0) return NULL;
        *detach = 1;
    } else if (r != JNI_OK) return NULL;
    return env;
}
static void releaseEnv(int detach) {
    if (detach && g_jvm != NULL) (*g_jvm)->DetachCurrentThread(g_jvm);
}
static int callProtect(int fd) {
    if (g_vpn_cls == NULL || g_protect_mid == NULL) return 0;
    int detach = 0;
    JNIEnv* env = getEnv(&detach);
    if (env == NULL) return 0;
    jboolean ok = (*env)->CallStaticBooleanMethod(env, g_vpn_cls, g_protect_mid, (jint)fd);
    releaseEnv(detach);
    return ok == JNI_TRUE;
}
static const char* jstringToChars(JNIEnv* env, jstring j) {
    if (j == NULL) return NULL;
    return (*env)->GetStringUTFChars(env, j, NULL);
}
static void releaseChars(JNIEnv* env, jstring j, const char* chars) {
    if (j != NULL && chars != NULL) (*env)->ReleaseStringUTFChars(env, j, chars);
}
static jstring newString(JNIEnv* env, const char* s) { return (*env)->NewStringUTF(env, s); }
*/
import "C"

import (
	"context"
	"crypto/tls"
	"errors"
	"fmt"
	"net"
	"net/netip"
	"os"
	"path/filepath"
	"strconv"
	"sync"
	"time"
	"unsafe"

	"graftmasque/androidvpn"
	"graftmasque/registration"
	"graftmasque/tunnel"
)

var runtimeState struct {
	sync.Mutex
	cancel   context.CancelFunc
	client   *tunnel.MasqueClient
	vpn      *androidvpn.Vpn
	prepared bool
	running  bool
	lastErr  string
}

func resultString(env *C.JNIEnv, s string) C.jstring {
	cs := C.CString(s)
	defer C.free(unsafe.Pointer(cs))
	return C.newString(env, cs)
}

func loadOrRegister(path string) (*registration.Registration, error) {
	if r, err := registration.Load(path); err == nil {
		return r, nil
	}
	r, err := registration.Register()
	if err != nil {
		return nil, err
	}
	if err := r.Save(path); err != nil {
		return nil, err
	}
	return r, nil
}

func edgeCandidates(r *registration.Registration) []string {
	ports := append([]int(nil), r.EndpointPorts...)
	if len(ports) == 0 {
		ports = []int{443, 500, 4500}
	}
	preferred := []int{443, 500, 4500}
	for _, p := range ports {
		found := false
		for _, q := range preferred {
			if p == q {
				found = true
				break
			}
		}
		if !found {
			preferred = append(preferred, p)
		}
	}
	seen := map[string]bool{}
	out := []string{}
	for _, p := range preferred {
		for _, host := range []string{r.EndpointV4, r.EndpointV6} {
			if host == "" {
				continue
			}
			a := net.JoinHostPort(host, strconv.Itoa(p))
			if !seen[a] {
				seen[a] = true
				out = append(out, a)
			}
		}
	}
	return out
}

func buildTLS(r *registration.Registration) (*tls.Config, error) {
	verify, err := r.PeerPublicKeyVerifier()
	if err != nil {
		return nil, err
	}
	return &tls.Config{
		ServerName:            "consumer-masque-proxy.cloudflareclient.com",
		NextProtos:            []string{"h3"},
		InsecureSkipVerify:    true,
		MinVersion:            tls.VersionTLS13,
		Certificates:          []tls.Certificate{r.ClientCert},
		VerifyPeerCertificate: verify,
		CurvePreferences:      []tls.CurveID{tls.CurveP256, tls.CurveP384, tls.CurveP521},
	}, nil
}

func protectSocket(fd int) error {
	if C.callProtect(C.int(fd)) == 0 {
		return errors.New("VpnService.protect failed")
	}
	return nil
}

func stopLocked() {
	if runtimeState.cancel != nil {
		runtimeState.cancel()
		runtimeState.cancel = nil
	}
	if runtimeState.vpn != nil {
		_ = runtimeState.vpn.Stop()
		runtimeState.vpn = nil
	}
	if runtimeState.client != nil {
		_ = runtimeState.client.Close()
		runtimeState.client = nil
	}
	runtimeState.prepared = false
	runtimeState.running = false
}

//export Java_com_iknalos_warpgo_MasqueGraft_nativeTest
func Java_com_iknalos_warpgo_MasqueGraft_nativeTest(env *C.JNIEnv, clazz C.jclass, filesDir C.jstring) C.jstring {
	chars := C.jstringToChars(env, filesDir)
	if chars == nil {
		return resultString(env, "ERROR: no files directory")
	}
	dir := C.GoString(chars)
	C.releaseChars(env, filesDir, chars)
	if err := os.MkdirAll(dir, 0700); err != nil {
		return resultString(env, "ERROR: "+err.Error())
	}
	reg, err := loadOrRegister(filepath.Join(dir, "masque_graft_reg.json"))
	if err != nil {
		return resultString(env, "ERROR: MASQUE registration: "+err.Error())
	}
	tc, err := buildTLS(reg)
	if err != nil {
		return resultString(env, "ERROR: TLS: "+err.Error())
	}
	edges := edgeCandidates(reg)
	if len(edges) == 0 {
		return resultString(env, "ERROR: no MASQUE edge")
	}
	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()
	client, err := tunnel.NewMasqueClientContext(ctx, edges, tc, reg.Token)
	if err != nil {
		return resultString(env, "ERROR: MASQUE handshake: "+err.Error())
	}
	_ = client.Close()
	return resultString(env, fmt.Sprintf("MASQUE handshake OK · %d edge candidates", len(edges)))
}

// nativePrepare deliberately runs BEFORE Builder.establish().  The VpnService
// instance already exists, so protect(fd) is available, but Android has not yet
// installed a default VPN route.  Registration and the QUIC control socket can
// therefore never be trapped inside the tunnel they are trying to create.
//
//export Java_com_iknalos_warpgo_MasqueVpnService_nativePrepare
func Java_com_iknalos_warpgo_MasqueVpnService_nativePrepare(env *C.JNIEnv, clazz C.jclass, filesDir C.jstring) C.jstring {
	C.rememberVM(env)
	C.rememberVpnClass(env, clazz)
	chars := C.jstringToChars(env, filesDir)
	if chars == nil {
		return resultString(env, "ERROR: no files directory")
	}
	dir := C.GoString(chars)
	C.releaseChars(env, filesDir, chars)

	runtimeState.Lock()
	defer runtimeState.Unlock()
	stopLocked()
	runtimeState.lastErr = ""

	if err := os.MkdirAll(dir, 0700); err != nil {
		runtimeState.lastErr = err.Error()
		return resultString(env, "ERROR: "+err.Error())
	}
	reg, err := loadOrRegister(filepath.Join(dir, "masque_graft_reg.json"))
	if err != nil {
		runtimeState.lastErr = err.Error()
		return resultString(env, "ERROR: registration: "+err.Error())
	}
	tc, err := buildTLS(reg)
	if err != nil {
		runtimeState.lastErr = err.Error()
		return resultString(env, "ERROR: TLS: "+err.Error())
	}
	edges := edgeCandidates(reg)
	if len(edges) == 0 {
		runtimeState.lastErr = "no MASQUE edge"
		return resultString(env, "ERROR: no MASQUE edge")
	}

	tunnel.SetSocketProtector(protectSocket)
	androidvpn.SetSocketProtector(protectSocket)

	ctx, cancel := context.WithTimeout(context.Background(), 45*time.Second)
	client, err := tunnel.NewMasqueClientContext(ctx, edges, tc, reg.Token)
	cancel()
	if err != nil {
		runtimeState.lastErr = err.Error()
		return resultString(env, "ERROR: MASQUE prepare: "+err.Error())
	}

	runtimeState.client = client
	runtimeState.prepared = true
	return resultString(env, "OK: MASQUE prepared")
}

//export Java_com_iknalos_warpgo_MasqueVpnService_nativeAttach
func Java_com_iknalos_warpgo_MasqueVpnService_nativeAttach(env *C.JNIEnv, clazz C.jclass, fd C.jint) C.jstring {
	runtimeState.Lock()
	defer runtimeState.Unlock()
	if !runtimeState.prepared || runtimeState.client == nil {
		runtimeState.lastErr = "MASQUE not prepared"
		return resultString(env, "ERROR: MASQUE not prepared")
	}

	runCtx, cancel := context.WithCancel(context.Background())
	cfg := androidvpn.Config{
		FileDescriptor: int(fd), MTU: 1400,
		Inet4Address: []netip.Prefix{netip.MustParsePrefix("172.16.0.2/32")},
		DNSServers:   []netip.Addr{androidvpn.DNSInterceptAddr},
		Route:        nil,
		TunnelDial:   runtimeState.client.DialTunnel,
		TunnelDNS:    runtimeState.client.ResolveDNS,
	}
	vpn, err := androidvpn.New(cfg)
	if err != nil {
		cancel()
		runtimeState.lastErr = err.Error()
		_ = runtimeState.client.Close()
		runtimeState.client = nil
		runtimeState.prepared = false
		return resultString(env, "ERROR: TUN: "+err.Error())
	}

	runtimeState.cancel = cancel
	runtimeState.vpn = vpn
	runtimeState.running = true
	go func() {
		err := vpn.Start(runCtx)
		runtimeState.Lock()
		if err != nil && runCtx.Err() == nil {
			runtimeState.lastErr = err.Error()
		}
		runtimeState.running = false
		runtimeState.Unlock()
	}()
	return resultString(env, "OK: MASQUE VPN attached")
}

//export Java_com_iknalos_warpgo_MasqueVpnService_nativeStop
func Java_com_iknalos_warpgo_MasqueVpnService_nativeStop(env *C.JNIEnv, clazz C.jclass) {
	runtimeState.Lock()
	stopLocked()
	runtimeState.Unlock()
}

//export Java_com_iknalos_warpgo_MasqueGraft_nativeIsRunning
func Java_com_iknalos_warpgo_MasqueGraft_nativeIsRunning(env *C.JNIEnv, clazz C.jclass) C.jboolean {
	runtimeState.Lock()
	r := runtimeState.running
	runtimeState.Unlock()
	if r {
		return C.jboolean(1)
	}
	return C.jboolean(0)
}

//export Java_com_iknalos_warpgo_MasqueGraft_nativeLastError
func Java_com_iknalos_warpgo_MasqueGraft_nativeLastError(env *C.JNIEnv, clazz C.jclass) C.jstring {
	runtimeState.Lock()
	s := runtimeState.lastErr
	runtimeState.Unlock()
	return resultString(env, s)
}

func main() {}
