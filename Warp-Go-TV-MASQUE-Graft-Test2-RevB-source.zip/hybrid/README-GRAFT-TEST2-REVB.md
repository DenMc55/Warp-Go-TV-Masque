# Graft Test 2 Rev B

Rev B changes the MASQUE startup order so Cloudflare registration and the QUIC/HTTP3 MASQUE session are established and socket-protected before Android installs the VPN default route. If MASQUE preparation fails, no TUN is created and normal device networking remains untouched.

It also adds a short handover delay when switching between WireGuard and MASQUE.
