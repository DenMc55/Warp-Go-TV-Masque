# Test O — Clean soft protocol reset

Baseline: Warp Go TV v1.5 WireGuard lifecycle + Test I UI/MASQUE.

Changes in Test O:
- Protocol selector remains disabled while any tunnel is active or the app is busy.
- WireGuard port choices are disabled while WireGuard is active or during transitions.
- Changing protocol while disconnected keeps MainActivity/UI open but performs a soft internal runtime restart:
  - stop MASQUE service/native runtime,
  - force native MASQUE stop as a stale-state safeguard,
  - force WireGuard DOWN,
  - discard in-memory WireGuard GoBackend/tunnel objects,
  - preserve both protocol registrations/account files,
  - select the new protocol in a clean disconnected state.
- No Test J–N timing/handover stack is carried forward.
- Version name: 1.5-test-o-soft-protocol-reset
