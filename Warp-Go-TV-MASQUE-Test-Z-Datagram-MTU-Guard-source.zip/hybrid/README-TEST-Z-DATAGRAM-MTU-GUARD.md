# Test Z — MASQUE DATAGRAM MTU Guard

Baseline: Test Y Verified Transport.

Targeted change only:
- MASQUE Android TUN MTU reduced from 1280 to 1100 bytes.
- Native CONNECT-IP pump adds a 1100-byte last-resort oversize guard so one packet cannot terminate the QUIC session with `DATAGRAM frame too large`.
- Test Y QUIC/UDP 443 + CONNECT-IP + tunnel verification remains intact.
- Test X process isolation/watchdog and WireGuard behaviour remain unchanged.

Purpose: confirm whether the intermittent MASQUE failure observed in Test Y is caused by inner packets exceeding the negotiated/path QUIC DATAGRAM payload limit.
