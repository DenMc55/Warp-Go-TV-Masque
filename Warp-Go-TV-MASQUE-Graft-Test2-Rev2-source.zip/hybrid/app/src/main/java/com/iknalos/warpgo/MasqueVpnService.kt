package com.iknalos.warpgo

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.IBinder
import android.os.ParcelFileDescriptor
import androidx.core.app.NotificationCompat

class MasqueVpnService : VpnService() {
    private var pfd: ParcelFileDescriptor? = null

    companion object {
        private const val CHANNEL = "warp_go_masque"
        private const val NOTIFICATION_ID = 4510
        @Volatile private var instance: MasqueVpnService? = null
        @Volatile private var active: Boolean = false

        init { System.loadLibrary("masquegraft") }

        @JvmStatic private external fun nativeStart(filesDir: String, fd: Int): String
        @JvmStatic private external fun nativeStop()

        @JvmStatic fun protectSocket(fd: Int): Boolean = try {
            instance?.protect(fd) ?: false
        } catch (_: Throwable) { false }

        fun isActive(): Boolean = active

        fun start(context: Context) {
            val i = Intent(context, MasqueVpnService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(i)
            else context.startService(i)
        }

        fun stop(context: Context) {
            try { nativeStop() } catch (_: Throwable) {}
            instance?.stopForeground(STOP_FOREGROUND_REMOVE)
            instance?.stopSelf()
            context.stopService(Intent(context, MasqueVpnService::class.java))
        }
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIFICATION_ID, notification("Connecting with MASQUE…"))
        if (pfd != null || MasqueGraft.nativeIsRunning()) return START_STICKY

        val builder = Builder()
            .setSession("Warp Go TV · MASQUE")
            .setMtu(1400)
            .setBlocking(true)
            .addAddress("172.16.0.2", 32)
            .addRoute("0.0.0.0", 0)
            .addDnsServer("198.18.0.1")

        val established = try { builder.establish() } catch (_: Throwable) { null }
        if (established == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        pfd = established
        val fd = established.detachFd()

        Thread {
            val result = try { nativeStart(filesDir.absolutePath, fd) }
            catch (t: Throwable) { "ERROR: ${t.message ?: t.javaClass.simpleName}" }
            if (result.startsWith("OK:")) {
                active = true
                val nm = getSystemService(NotificationManager::class.java)
                nm.notify(NOTIFICATION_ID, notification("Connected · MASQUE"))
            } else {
                active = false
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }.start()

        return START_STICKY
    }

    override fun onDestroy() {
        try { nativeStop() } catch (_: Throwable) {}
        try { pfd?.close() } catch (_: Throwable) {}
        pfd = null
        active = false
        instance = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = super.onBind(intent)

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(CHANNEL, "Warp Go TV MASQUE", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    private fun notification(text: String) = NotificationCompat.Builder(this, CHANNEL)
        .setSmallIcon(android.R.drawable.stat_sys_download_done)
        .setContentTitle("Warp Go TV")
        .setContentText(text)
        .setOngoing(true)
        .setPriority(NotificationCompat.PRIORITY_LOW)
        .setContentIntent(
            PendingIntent.getActivity(
                this, 0, Intent(this, MainActivity::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        )
        .build()
}
