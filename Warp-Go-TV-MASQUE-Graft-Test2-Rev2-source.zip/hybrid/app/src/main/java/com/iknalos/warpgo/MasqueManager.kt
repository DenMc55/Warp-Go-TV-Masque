package com.iknalos.warpgo

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import kotlinx.coroutines.delay

object MasqueManager {
    fun isUp(): Boolean = MasqueVpnService.isActive()

    private suspend fun waitForPhysicalNetwork(context: Context, timeoutMs: Long = 5000): Boolean {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        var waited = 0L
        while (waited <= timeoutMs) {
            val n = cm.activeNetwork
            val caps = n?.let { cm.getNetworkCapabilities(it) }
            if (caps != null && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
                !caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) {
                return true
            }
            delay(100)
            waited += 100
        }
        return false
    }

    suspend fun connect(context: Context) {
        val app = context.applicationContext
        if (!waitForPhysicalNetwork(app)) {
            throw IllegalStateException("No physical network available")
        }

        // IMPORTANT: register and establish the MASQUE/HTTP3 control session
        // BEFORE Android installs the VPN route. This prevents the client from
        // trapping its own Cloudflare API/DNS traffic inside the new tunnel.
        val prepared = try { MasqueGraft.nativePrepare(app.filesDir.absolutePath) }
        catch (t: Throwable) { "ERROR: ${t.message ?: t.javaClass.simpleName}" }
        if (!prepared.startsWith("OK:")) {
            throw IllegalStateException(prepared.removePrefix("ERROR: "))
        }

        MasqueVpnService.start(app)
        repeat(120) {
            if (isUp()) return
            val err = try { MasqueGraft.nativeLastError() } catch (_: Throwable) { "" }
            if (err.isNotBlank()) throw IllegalStateException(err)
            delay(100)
        }
        throw IllegalStateException("MASQUE connection timed out")
    }

    fun disconnect(context: Context) {
        MasqueVpnService.stop(context.applicationContext)
    }
}
