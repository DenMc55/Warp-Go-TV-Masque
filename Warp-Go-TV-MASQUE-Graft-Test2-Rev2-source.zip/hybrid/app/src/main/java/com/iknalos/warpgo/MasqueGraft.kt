package com.iknalos.warpgo

object MasqueGraft {
    init { System.loadLibrary("masquegraft") }
    external fun nativeTest(filesDir: String): String
    external fun nativePrepare(filesDir: String): String
    external fun nativeIsRunning(): Boolean
    external fun nativeLastError(): String
}
