package com.iknalos.warpgo

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.File

object MasqueManager {
    private const val DIAGNOSTIC_FILE = "masque_teste_stage.txt"

    fun isUp(): Boolean = try {
        MasqueGraft.nativeIsRunning()
    } catch (_: Throwable) {
        false
    }

    fun lastDiagnostic(context: Context): String {
        return try {
            File(context.filesDir, DIAGNOSTIC_FILE).takeIf { it.exists() }
                ?.readText()?.trim().orEmpty()
        } catch (_: Throwable) { "" }
    }

    suspend fun connect(context: Context) {
        withContext(Dispatchers.IO) {
            try { File(context.filesDir, DIAGNOSTIC_FILE).delete() } catch (_: Throwable) {}
        }

        // Test E intentionally enters through the real Android VpnService so
        // the QUIC UDP socket must be protected from VPN routing.
        MasqueVpnService.start(context.applicationContext)

        repeat(120) {
            if (isUp()) return
            val stage = lastDiagnostic(context)
            if (stage.startsWith("ERROR:")) {
                throw IllegalStateException(stage.removePrefix("ERROR:").trim())
            }
            delay(100)
        }

        val stage = lastDiagnostic(context)
        val nativeError = try { MasqueGraft.nativeLastError() } catch (_: Throwable) { "" }
        MasqueVpnService.stop(context.applicationContext)
        throw IllegalStateException(
            when {
                nativeError.isNotBlank() && stage.isNotBlank() -> "$nativeError · $stage"
                nativeError.isNotBlank() -> nativeError
                stage.isNotBlank() -> "MASQUE Test E timed out after [$stage]"
                else -> "MASQUE Test E service/core startup timed out"
            }
        )
    }

    fun disconnect(context: Context) {
        try { MasqueVpnService.stop(context.applicationContext) } catch (_: Throwable) {}
    }
}
