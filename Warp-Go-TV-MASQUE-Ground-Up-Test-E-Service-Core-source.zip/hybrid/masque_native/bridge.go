//go:build android && cgo

// Warp Go TV MASQUE clean core.
//
// This module is intentionally written as a fresh implementation. It does not
// import or compile any source package from the reference Android MASQUE app.
// Test E carries forward our own WARP registration, MASQUE credentials, edge discovery,
// socket protection and QUIC/HTTP/3 negotiation before we add the TUN data path.
package main

/*
#include <jni.h>
#include <stdlib.h>

static JavaVM* g_jvm = NULL;
static jclass g_vpn_cls = NULL;
static jmethodID g_protect_mid = NULL;

static void rememberVM(JNIEnv* env) {
    if (g_jvm == NULL) (*env)->GetJavaVM(env, &g_jvm);
}
static void rememberVpnClass(JNIEnv* env, jclass cls) {
    if (g_vpn_cls == NULL) g_vpn_cls = (*env)->NewGlobalRef(env, cls);
    if (g_protect_mid == NULL && g_vpn_cls != NULL) {
        g_protect_mid = (*env)->GetStaticMethodID(env, g_vpn_cls, "protectSocket", "(I)Z");
        if ((*env)->ExceptionCheck(env)) {
            (*env)->ExceptionClear(env);
            g_protect_mid = NULL;
        }
    }
}
static JNIEnv* getEnv(int* detach) {
    *detach = 0;
    if (g_jvm == NULL) return NULL;
    JNIEnv* env = NULL;
    jint r = (*g_jvm)->GetEnv(g_jvm, (void**)&env, JNI_VERSION_1_6);
    if (r == JNI_EDETACHED) {
        if ((*g_jvm)->AttachCurrentThread(g_jvm, &env, NULL) != 0) return NULL;
        *detach = 1;
    } else if (r != JNI_OK) return NULL;
    return env;
}
static void releaseEnv(int detach) {
    if (detach && g_jvm != NULL) (*g_jvm)->DetachCurrentThread(g_jvm);
}
static int callProtect(int fd) {
    if (g_vpn_cls == NULL || g_protect_mid == NULL) return 1; // diagnostic core path may run without a VPN
    int detach = 0;
    JNIEnv* env = getEnv(&detach);
    if (env == NULL) return 0;
    jboolean ok = (*env)->CallStaticBooleanMethod(env, g_vpn_cls, g_protect_mid, (jint)fd);
    releaseEnv(detach);
    return ok == JNI_TRUE;
}
static const char* jstringToChars(JNIEnv* env, jstring j) {
    if (j == NULL) return NULL;
    return (*env)->GetStringUTFChars(env, j, NULL);
}
static void releaseChars(JNIEnv* env, jstring j, const char* chars) {
    if (j != NULL && chars != NULL) (*env)->ReleaseStringUTFChars(env, j, chars);
}
static jstring newString(JNIEnv* env, const char* s) { return (*env)->NewStringUTF(env, s); }
*/
import "C"

import (
	"context"
	"crypto/ecdsa"
	"crypto/elliptic"
	"crypto/rand"
	"crypto/tls"
	"crypto/x509"
	"crypto/x509/pkix"
	"encoding/base64"
	"encoding/json"
	"encoding/pem"
	"errors"
	"fmt"
	"io"
	"math/big"
	"net"
	"net/http"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"sync"
	"time"
	"unsafe"

	"github.com/quic-go/quic-go"
	"github.com/quic-go/quic-go/http3"
	"golang.org/x/crypto/curve25519"
)

const (
	apiBase            = "https://api.cloudflareclient.com/v0"
	userAgent          = "WARP for Linux"
	clientVersion      = "linux-2026.6.880.0"
	masqueServerName   = "consumer-masque-proxy.cloudflareclient.com"
	connectionIDLength = 20
)

type registrationState struct {
	ID            string `json:"id"`
	Token         string `json:"token"`
	Account       string `json:"account,omitempty"`
	PrivateKeyB64 string `json:"private_key"`
	EndpointV4    string `json:"endpoint_v4,omitempty"`
	EndpointV6    string `json:"endpoint_v6,omitempty"`
	EndpointPorts []int  `json:"endpoint_ports,omitempty"`
	PeerPublicKey string `json:"peer_public_key,omitempty"`
	AssignedIPv4  string `json:"assigned_ipv4,omitempty"`
	AssignedIPv6  string `json:"assigned_ipv6,omitempty"`
}

var state struct {
	sync.Mutex
	running   bool
	lastErr   string
	conn      *quic.Conn
	transport *quic.Transport
	udp       *net.UDPConn
	h3        *http3.Transport
}

func main() {}

func resultString(env *C.JNIEnv, s string) C.jstring {
	cs := C.CString(s)
	defer C.free(unsafe.Pointer(cs))
	return C.newString(env, cs)
}

func randomWireGuardPublicKey() (string, error) {
	privateKey := make([]byte, 32)
	if _, err := rand.Read(privateKey); err != nil {
		return "", err
	}
	privateKey[0] &= 248
	privateKey[31] &= 127
	privateKey[31] |= 64
	publicKey, err := curve25519.X25519(privateKey, curve25519.Basepoint)
	if err != nil {
		return "", err
	}
	return base64.StdEncoding.EncodeToString(publicKey), nil
}

func randomSerial() (string, error) {
	b := make([]byte, 8)
	if _, err := rand.Read(b); err != nil {
		return "", err
	}
	return fmt.Sprintf("%x", b), nil
}

func privateKeyToB64(key *ecdsa.PrivateKey) (string, error) {
	der, err := x509.MarshalECPrivateKey(key)
	if err != nil {
		return "", err
	}
	return base64.StdEncoding.EncodeToString(der), nil
}

func privateKeyFromB64(s string) (*ecdsa.PrivateKey, error) {
	der, err := base64.StdEncoding.DecodeString(strings.TrimSpace(s))
	if err != nil {
		return nil, fmt.Errorf("saved MASQUE private key is invalid: %w", err)
	}
	key, err := x509.ParseECPrivateKey(der)
	if err != nil {
		return nil, fmt.Errorf("saved MASQUE private key cannot be parsed: %w", err)
	}
	return key, nil
}

func buildClientCertificate(id string, key *ecdsa.PrivateKey) (tls.Certificate, error) {
	now := time.Now()
	tmpl := &x509.Certificate{
		SerialNumber: big.NewInt(now.UnixNano()),
		Subject:      pkix.Name{CommonName: id + ".masque2.cloudflareclient.com"},
		NotBefore:    now.Add(-time.Minute),
		NotAfter:     now.Add(24 * time.Hour),
		KeyUsage:     x509.KeyUsageDigitalSignature,
		ExtKeyUsage:  []x509.ExtKeyUsage{x509.ExtKeyUsageClientAuth},
	}
	der, err := x509.CreateCertificate(rand.Reader, tmpl, tmpl, &key.PublicKey, key)
	if err != nil {
		return tls.Certificate{}, fmt.Errorf("create MASQUE client certificate: %w", err)
	}
	return tls.Certificate{Certificate: [][]byte{der}, PrivateKey: key}, nil
}

func endpointHost(value string) string {
	value = strings.TrimSpace(value)
	if value == "" {
		return ""
	}
	if h, _, err := net.SplitHostPort(value); err == nil {
		return h
	}
	return strings.Trim(value, "[]")
}

func registerFresh(ctx context.Context) (*registrationState, error) {
	wgPublic, err := randomWireGuardPublicKey()
	if err != nil {
		return nil, fmt.Errorf("create bootstrap key: %w", err)
	}
	serial, err := randomSerial()
	if err != nil {
		return nil, fmt.Errorf("create installation serial: %w", err)
	}

	createBody := map[string]any{
		"key":           wgPublic,
		"install_id":    "",
		"fcm_token":     "",
		"tos":           time.Now().Format("2006-01-02T15:04:05.000-07:00"),
		"model":         "PC",
		"serial_number": serial,
		"os_version":    "",
		"key_type":      "curve25519",
		"tunnel_type":   "wireguard",
		"locale":        "en_US",
		"warp_enabled":  true,
	}
	body, _ := json.Marshal(createBody)
	req, err := http.NewRequestWithContext(ctx, http.MethodPost, apiBase+"/reg", strings.NewReader(string(body)))
	if err != nil {
		return nil, fmt.Errorf("create Cloudflare registration request: %w", err)
	}
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("User-Agent", userAgent)
	req.Header.Set("CF-Client-Version", clientVersion)

	client := &http.Client{Timeout: 30 * time.Second}
	resp, err := client.Do(req)
	if err != nil {
		return nil, fmt.Errorf("Cloudflare registration request failed: %w", err)
	}
	createRaw, readErr := io.ReadAll(resp.Body)
	resp.Body.Close()
	if readErr != nil {
		return nil, fmt.Errorf("read Cloudflare registration response: %w", readErr)
	}
	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("Cloudflare registration returned HTTP %d", resp.StatusCode)
	}

	var create struct {
		Result struct {
			ID      string `json:"id"`
			Token   string `json:"token"`
			Account struct {
				ID string `json:"id"`
			} `json:"account"`
		} `json:"result"`
	}
	if err := json.Unmarshal(createRaw, &create); err != nil {
		return nil, fmt.Errorf("parse Cloudflare registration response: %w", err)
	}
	if create.Result.ID == "" || create.Result.Token == "" {
		return nil, errors.New("Cloudflare registration response did not contain an id and token")
	}

	masqueKey, err := ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
	if err != nil {
		return nil, fmt.Errorf("create MASQUE P-256 key: %w", err)
	}
	pubDER, err := x509.MarshalPKIXPublicKey(&masqueKey.PublicKey)
	if err != nil {
		return nil, fmt.Errorf("encode MASQUE public key: %w", err)
	}
	enrollBody := map[string]any{
		"key":         base64.StdEncoding.EncodeToString(pubDER),
		"key_type":    "secp256r1",
		"tunnel_type": "masque",
	}
	enrollJSON, _ := json.Marshal(enrollBody)
	enrollReq, err := http.NewRequestWithContext(ctx, http.MethodPatch, apiBase+"/reg/"+create.Result.ID, strings.NewReader(string(enrollJSON)))
	if err != nil {
		return nil, fmt.Errorf("create MASQUE enrollment request: %w", err)
	}
	enrollReq.Header.Set("Content-Type", "application/json")
	enrollReq.Header.Set("User-Agent", userAgent)
	enrollReq.Header.Set("CF-Client-Version", clientVersion)
	enrollReq.Header.Set("Authorization", "Bearer "+create.Result.Token)
	enrollResp, err := client.Do(enrollReq)
	if err != nil {
		return nil, fmt.Errorf("Cloudflare MASQUE enrollment request failed: %w", err)
	}
	enrollRaw, readErr := io.ReadAll(enrollResp.Body)
	enrollResp.Body.Close()
	if readErr != nil {
		return nil, fmt.Errorf("read Cloudflare MASQUE enrollment response: %w", readErr)
	}
	if enrollResp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("Cloudflare MASQUE enrollment returned HTTP %d", enrollResp.StatusCode)
	}

	var enroll struct {
		Result struct {
			ID      string `json:"id"`
			Account struct {
				ID string `json:"id"`
			} `json:"account"`
			Config struct {
				Peers []struct {
					PublicKey string `json:"public_key"`
					Endpoint  struct {
						V4    string `json:"v4"`
						V6    string `json:"v6"`
						Host  string `json:"host"`
						Ports []int  `json:"ports"`
					} `json:"endpoint"`
				} `json:"peers"`
				Interface struct {
					Addresses struct {
						V4 string `json:"v4"`
						V6 string `json:"v6"`
					} `json:"addresses"`
				} `json:"interface"`
			} `json:"config"`
		} `json:"result"`
	}
	if err := json.Unmarshal(enrollRaw, &enroll); err != nil {
		return nil, fmt.Errorf("parse Cloudflare MASQUE enrollment response: %w", err)
	}

	privateB64, err := privateKeyToB64(masqueKey)
	if err != nil {
		return nil, fmt.Errorf("save MASQUE private key: %w", err)
	}
	r := &registrationState{
		ID:            create.Result.ID,
		Token:         create.Result.Token,
		Account:       create.Result.Account.ID,
		PrivateKeyB64: privateB64,
		AssignedIPv4:  enroll.Result.Config.Interface.Addresses.V4,
		AssignedIPv6:  enroll.Result.Config.Interface.Addresses.V6,
	}
	if len(enroll.Result.Config.Peers) > 0 {
		p := enroll.Result.Config.Peers[0]
		r.EndpointV4 = endpointHost(p.Endpoint.V4)
		r.EndpointV6 = endpointHost(p.Endpoint.V6)
		if r.EndpointV4 == "" && r.EndpointV6 == "" {
			r.EndpointV4 = endpointHost(p.Endpoint.Host)
		}
		r.EndpointPorts = append([]int(nil), p.Endpoint.Ports...)
		if block, _ := pem.Decode([]byte(p.PublicKey)); block != nil {
			r.PeerPublicKey = base64.StdEncoding.EncodeToString(block.Bytes)
		}
	}
	if r.ID == "" {
		r.ID = enroll.Result.ID
	}
	return r, nil
}

func saveRegistration(path string, r *registrationState) error {
	tmp := path + ".tmp"
	data, err := json.MarshalIndent(r, "", "  ")
	if err != nil {
		return err
	}
	if err := os.WriteFile(tmp, data, 0600); err != nil {
		return err
	}
	return os.Rename(tmp, path)
}

func loadRegistration(path string) (*registrationState, error) {
	data, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	var r registrationState
	if err := json.Unmarshal(data, &r); err != nil {
		return nil, err
	}
	if r.ID == "" || r.Token == "" || r.PrivateKeyB64 == "" {
		return nil, errors.New("saved MASQUE registration is incomplete")
	}
	return &r, nil
}

func loadOrCreateRegistration(ctx context.Context, path string) (*registrationState, error) {
	if r, err := loadRegistration(path); err == nil {
		return r, nil
	}
	// Build new state in memory first. The old file is never overwritten unless
	// the complete two-step registration succeeds.
	r, err := registerFresh(ctx)
	if err != nil {
		return nil, err
	}
	if err := saveRegistration(path, r); err != nil {
		return nil, fmt.Errorf("persist MASQUE registration: %w", err)
	}
	return r, nil
}

func peerVerifier(peerB64 string) (func([][]byte, [][]*x509.Certificate) error, error) {
	if strings.TrimSpace(peerB64) == "" {
		return nil, nil
	}
	der, err := base64.StdEncoding.DecodeString(peerB64)
	if err != nil {
		return nil, fmt.Errorf("decode registered edge public key: %w", err)
	}
	expectedAny, err := x509.ParsePKIXPublicKey(der)
	if err != nil {
		return nil, fmt.Errorf("parse registered edge public key: %w", err)
	}
	expected, ok := expectedAny.(*ecdsa.PublicKey)
	if !ok {
		return nil, fmt.Errorf("registered edge public key is %T, expected ECDSA", expectedAny)
	}
	return func(rawCerts [][]byte, _ [][]*x509.Certificate) error {
		if len(rawCerts) == 0 {
			return errors.New("MASQUE edge supplied no certificate")
		}
		cert, err := x509.ParseCertificate(rawCerts[0])
		if err != nil {
			return fmt.Errorf("parse MASQUE edge certificate: %w", err)
		}
		got, ok := cert.PublicKey.(*ecdsa.PublicKey)
		if !ok || !got.Equal(expected) {
			return errors.New("MASQUE edge public key does not match registration")
		}
		return nil
	}, nil
}

func edgeCandidates(r *registrationState) []string {
	ports := append([]int(nil), r.EndpointPorts...)
	if len(ports) == 0 {
		ports = []int{443, 500, 4500}
	}
	preferred := []int{443, 500, 4500}
	seenPort := map[int]bool{}
	ordered := make([]int, 0, len(preferred)+len(ports))
	for _, p := range append(preferred, ports...) {
		if p > 0 && !seenPort[p] {
			seenPort[p] = true
			ordered = append(ordered, p)
		}
	}
	seen := map[string]bool{}
	out := []string{}
	for _, p := range ordered {
		for _, host := range []string{r.EndpointV4, r.EndpointV6} {
			if host == "" {
				continue
			}
			a := net.JoinHostPort(host, strconv.Itoa(p))
			if !seen[a] {
				seen[a] = true
				out = append(out, a)
			}
		}
	}
	return out
}

func protectUDP(conn *net.UDPConn) error {
	raw, err := conn.SyscallConn()
	if err != nil {
		return err
	}
	var protectErr error
	err = raw.Control(func(fd uintptr) {
		if C.callProtect(C.int(fd)) == 0 {
			protectErr = errors.New("Android VpnService socket protection failed")
		}
	})
	if err != nil {
		return err
	}
	return protectErr
}

func cleanCloseLocked() {
	if state.h3 != nil {
		_ = state.h3.Close()
		state.h3 = nil
	}
	if state.transport != nil {
		_ = state.transport.Close()
		state.transport = nil
	}
	if state.udp != nil {
		_ = state.udp.Close()
		state.udp = nil
	}
	state.conn = nil
	state.running = false
}

func diagnosticPath(filesDir string) string {
	return filepath.Join(filesDir, "masque_teste_stage.txt")
}

func writeDiagnostic(filesDir, stage string) {
	_ = os.MkdirAll(filesDir, 0700)
	_ = os.WriteFile(diagnosticPath(filesDir), []byte(stage+"\n"), 0600)
}

func connectCore(ctx context.Context, filesDir string) error {
	writeDiagnostic(filesDir, "01 starting clean MASQUE core")

	regPath := filepath.Join(filesDir, "masque_clean_reg.json")
	writeDiagnostic(filesDir, "02 loading or creating Cloudflare registration")
	r, err := loadOrCreateRegistration(ctx, regPath)
	if err != nil {
		return err
	}
	writeDiagnostic(filesDir, "03 registration ready; loading MASQUE private key")
	key, err := privateKeyFromB64(r.PrivateKeyB64)
	if err != nil {
		return err
	}
	writeDiagnostic(filesDir, "04 private key ready; building client certificate")
	cert, err := buildClientCertificate(r.ID, key)
	if err != nil {
		return err
	}
	writeDiagnostic(filesDir, "05 certificate ready; preparing edge verification")
	verify, err := peerVerifier(r.PeerPublicKey)
	if err != nil {
		return err
	}
	tlsConfig := &tls.Config{
		ServerName:            masqueServerName,
		NextProtos:            []string{"h3"},
		MinVersion:            tls.VersionTLS13,
		InsecureSkipVerify:    true,
		Certificates:          []tls.Certificate{cert},
		VerifyPeerCertificate: verify,
	}
	qcfg := &quic.Config{
		EnableDatagrams:      true,
		KeepAlivePeriod:      15 * time.Second,
		MaxIdleTimeout:       45 * time.Second,
		HandshakeIdleTimeout: 5 * time.Second,
	}
	writeDiagnostic(filesDir, "06 TLS and QUIC configuration ready; selecting edge")
	candidates := edgeCandidates(r)
	if len(candidates) == 0 {
		return errors.New("Cloudflare registration did not provide a MASQUE edge")
	}

	var lastErr error
	for _, addr := range candidates {
		writeDiagnostic(filesDir, "07 resolving edge "+addr)
		udpAddr, err := net.ResolveUDPAddr("udp", addr)
		if err != nil {
			lastErr = err
			continue
		}
		family := "udp4"
		bind := &net.UDPAddr{IP: net.IPv4zero}
		if udpAddr.IP.To4() == nil {
			family = "udp6"
			bind = &net.UDPAddr{IP: net.IPv6zero}
		}
		writeDiagnostic(filesDir, "08 opening UDP socket for "+addr)
		udpConn, err := net.ListenUDP(family, bind)
		if err != nil {
			lastErr = err
			continue
		}
		writeDiagnostic(filesDir, "09 protecting UDP socket from VPN routing")
		if err := protectUDP(udpConn); err != nil {
			udpConn.Close()
			return err
		}
		writeDiagnostic(filesDir, "10 UDP socket ready; creating QUIC transport")
		transport := &quic.Transport{Conn: udpConn, ConnectionIDLength: connectionIDLength}
		attemptCtx, cancel := context.WithTimeout(ctx, 3*time.Second)
		writeDiagnostic(filesDir, "11 starting QUIC TLS handshake with "+addr)
		conn, err := transport.Dial(attemptCtx, udpAddr, tlsConfig.Clone(), qcfg)
		cancel()
		if err != nil {
			transport.Close()
			udpConn.Close()
			lastErr = fmt.Errorf("QUIC %s: %w", addr, err)
			continue
		}
		writeDiagnostic(filesDir, "12 QUIC connected; creating HTTP/3 client")
		h3 := &http3.Transport{TLSClientConfig: tlsConfig.Clone(), QUICConfig: qcfg, EnableDatagrams: true}
		clientConn := h3.NewClientConn(conn)
		writeDiagnostic(filesDir, "13 HTTP/3 client created; waiting for SETTINGS")
		timer := time.NewTimer(6 * time.Second)
		select {
		case <-clientConn.ReceivedSettings():
			timer.Stop()
			settings := clientConn.Settings()
			if !settings.EnableExtendedConnect {
				h3.Close()
				transport.Close()
				udpConn.Close()
				lastErr = errors.New("Cloudflare edge did not advertise HTTP/3 Extended CONNECT")
				continue
			}
			state.conn = conn
			state.transport = transport
			state.udp = udpConn
			state.h3 = h3
			state.running = true
			writeDiagnostic(filesDir, "14 MASQUE core ready; Extended CONNECT advertised")
			return nil
		case <-conn.Context().Done():
			timer.Stop()
			h3.Close()
			transport.Close()
			udpConn.Close()
			lastErr = fmt.Errorf("HTTP/3 session ended during setup: %v", context.Cause(conn.Context()))
		case <-timer.C:
			h3.Close()
			transport.Close()
			udpConn.Close()
			lastErr = errors.New("timed out waiting for HTTP/3 SETTINGS")
		case <-ctx.Done():
			timer.Stop()
			h3.Close()
			transport.Close()
			udpConn.Close()
			return ctx.Err()
		}
	}
	if lastErr == nil {
		lastErr = errors.New("no MASQUE edge candidate succeeded")
	}
	return lastErr
}

func runConnect(filesDir string) string {
	state.Lock()
	defer state.Unlock()
	cleanCloseLocked()
	state.lastErr = ""
	if err := os.MkdirAll(filesDir, 0700); err != nil {
		state.lastErr = err.Error()
		return "ERROR: " + err.Error()
	}
	ctx, cancel := context.WithTimeout(context.Background(), 45*time.Second)
	defer cancel()
	if err := connectCore(ctx, filesDir); err != nil {
		state.lastErr = err.Error()
		writeDiagnostic(filesDir, "ERROR: "+err.Error())
		cleanCloseLocked()
		return "ERROR: " + err.Error()
	}
	return "OK: clean MASQUE registration + QUIC/HTTP3 core ready"
}

//export Java_com_iknalos_warpgo_MasqueGraft_nativeTest
func Java_com_iknalos_warpgo_MasqueGraft_nativeTest(env *C.JNIEnv, clazz C.jclass, filesDir C.jstring) C.jstring {
	C.rememberVM(env)
	// Test E retains nativeTest as a no-TUN fallback and does NOT call rememberVpnClass here. `clazz` is
	// MasqueGraft, not MasqueVpnService. Asking JNI for protectSocket on the
	// wrong class leaves a pending NoSuchMethodError and can terminate the app.
	// The clean-core test has no Android TUN, so socket protection is a no-op.
	_ = clazz
	chars := C.jstringToChars(env, filesDir)
	if chars == nil {
		return resultString(env, "ERROR: no files directory")
	}
	dir := C.GoString(chars)
	C.releaseChars(env, filesDir, chars)
	return resultString(env, runConnect(dir))
}

// Test E service entry point. Android establishes a limited diagnostic TUN and
// this path proves JNI VpnService socket protection plus the clean MASQUE core.
// The TUN fd is intentionally not consumed yet; full packet forwarding is the next stage.
//
//export Java_com_iknalos_warpgo_MasqueVpnService_nativeStart
func Java_com_iknalos_warpgo_MasqueVpnService_nativeStart(env *C.JNIEnv, clazz C.jclass, filesDir C.jstring, fd C.jint) C.jstring {
	C.rememberVM(env)
	C.rememberVpnClass(env, clazz)
	chars := C.jstringToChars(env, filesDir)
	if chars == nil {
		return resultString(env, "ERROR: no files directory")
	}
	dir := C.GoString(chars)
	C.releaseChars(env, filesDir, chars)
	return resultString(env, runConnect(dir))
}

//export Java_com_iknalos_warpgo_MasqueGraft_nativeIsRunning
func Java_com_iknalos_warpgo_MasqueGraft_nativeIsRunning(env *C.JNIEnv, clazz C.jclass) C.jboolean {
	state.Lock()
	defer state.Unlock()
	if state.running {
		return C.JNI_TRUE
	}
	return C.JNI_FALSE
}

//export Java_com_iknalos_warpgo_MasqueGraft_nativeLastError
func Java_com_iknalos_warpgo_MasqueGraft_nativeLastError(env *C.JNIEnv, clazz C.jclass) C.jstring {
	state.Lock()
	defer state.Unlock()
	return resultString(env, state.lastErr)
}

//export Java_com_iknalos_warpgo_MasqueVpnService_nativeStop
func Java_com_iknalos_warpgo_MasqueVpnService_nativeStop(env *C.JNIEnv, clazz C.jclass) {
	state.Lock()
	defer state.Unlock()
	cleanCloseLocked()
	state.lastErr = ""
}
