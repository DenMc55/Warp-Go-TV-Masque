# Test AB - Dynamic MASQUE PMTU

Based on Test AA. Keeps the Android TUN MTU at 1280 and the verified QUIC/UDP 443 / CONNECT-IP checks.

When quic-go reports a DATAGRAM payload ceiling smaller than the attempted CONNECT-IP packet, the native core now learns the live inner-packet ceiling (`MaxDatagramPayloadSize - 1` for Context ID 0), keeps the MASQUE session alive, drops only the oversized packet, and injects an IPv4 ICMP Fragmentation Needed or IPv6 ICMPv6 Packet Too Big response into the TUN. Later packets above the learned ceiling are handled before SendDatagram is attempted.

This is dynamic; no fixed 1243-byte QUIC ceiling is baked in.
