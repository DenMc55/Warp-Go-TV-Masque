# Test X — MASQUE isolated-process watchdog

Built from Test W. If MASQUE disconnect does not complete within the existing 5 second confirmation window, the main process kills only the isolated `:masque` process, publishes STOPPED state, waits 500 ms, then keeps the existing 1 second fresh-session pause. UI and WireGuard remain alive.
