# Test Y — MASQUE verified connection

Baseline: Test X.

A MASQUE connection is not published as RUNNING until all of these pass:

1. Native QUIC session is live.
2. The protected outer MASQUE endpoint is UDP port 443.
3. The Cloudflare `cf-connect-ip` request stream is established.
4. A normal, unprotected HTTPS request to Cloudflare trace succeeds through the full-route Android TUN.
5. Native CONNECT-IP packet counters show packets in both directions.

The isolated MASQUE service also monitors the native session after connection. If QUIC/CONNECT-IP later dies, RUNNING is withdrawn and the service tears itself down instead of leaving a stale green UI state.

WireGuard and Test X process isolation/watchdog behaviour are unchanged.
