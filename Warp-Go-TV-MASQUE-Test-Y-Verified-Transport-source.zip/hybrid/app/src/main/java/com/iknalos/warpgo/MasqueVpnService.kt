package com.iknalos.warpgo

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.IBinder
import android.os.ParcelFileDescriptor
import androidx.core.app.NotificationCompat
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

class MasqueVpnService : VpnService() {
    private var pfd: ParcelFileDescriptor? = null
    @Volatile private var shuttingDown = false
    @Volatile private var starting = false

    companion object {
        private const val CHANNEL = "warp_go_masque"
        private const val NOTIFICATION_ID = 4510
        @Volatile private var instance: MasqueVpnService? = null

        init { System.loadLibrary("warpmasque") }

        @JvmStatic private external fun nativePrepare(filesDir: String): String
        @JvmStatic private external fun nativeStart(filesDir: String, fd: Int): String
        @JvmStatic private external fun nativeStop()
        @JvmStatic private external fun nativeTransportStatus(): String

        @JvmStatic fun protectSocket(fd: Int): Boolean = try {
            instance?.protect(fd) ?: false
        } catch (_: Throwable) { false }

        fun isServiceActive(): Boolean = instance != null

    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        MasqueProcessState.write(this, "STARTING")
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIFICATION_ID, notification("Starting MASQUE full tunnel on UDP 443…"))
        if (starting || pfd != null || MasqueCore.nativeIsRunning()) return START_STICKY
        starting = true
        shuttingDown = false

        Thread {
            try {
                // Registration is performed before the full-device TUN exists. This lets
                // Android use Cloudflare's independently assigned MASQUE addresses while
                // leaving the WireGuard account/configuration untouched.
                val prepared = try { nativePrepare(filesDir.absolutePath) }
                catch (t: Throwable) { "ERROR: ${t.message ?: t.javaClass.simpleName}" }
                if (!prepared.startsWith("OK:")) {
                    shutdownForHandoff()
                    return@Thread
                }

                val addresses = prepared.removePrefix("OK:").split("|", limit = 2)
                val v4 = parseAddress(addresses.getOrNull(0).orEmpty(), 32)
                val v6 = parseAddress(addresses.getOrNull(1).orEmpty(), 128)
                if (v4.first.isBlank() && v6.first.isBlank()) {
                    shutdownForHandoff()
                    return@Thread
                }

                val builder = Builder()
                    .setSession("Warp Go TV · MASQUE · UDP 443")
                    .setMtu(1280)
                    .setBlocking(true)

                if (v4.first.isNotBlank()) {
                    builder.addAddress(v4.first, v4.second)
                    builder.addRoute("0.0.0.0", 0)
                    builder.addDnsServer("1.1.1.1")
                    builder.addDnsServer("1.0.0.1")
                }
                if (v6.first.isNotBlank()) {
                    builder.addAddress(v6.first, v6.second)
                    builder.addRoute("::", 0)
                    builder.addDnsServer("2606:4700:4700::1111")
                    builder.addDnsServer("2606:4700:4700::1001")
                }

                val established = try { builder.establish() } catch (_: Throwable) { null }
                if (established == null) {
                    shutdownForHandoff()
                    return@Thread
                }
                pfd = established
                val fd = established.detachFd()
                // detachFd transfers ownership to the Go core.
                pfd = null

                val result = try { nativeStart(filesDir.absolutePath, fd) }
                catch (t: Throwable) { "ERROR: ${t.message ?: t.javaClass.simpleName}" }
                if (result.startsWith("OK:")) {
                    // Test Y: native startup alone is not enough.  Verify the real
                    // MASQUE transport and prove bidirectional traffic through the TUN
                    // before publishing RUNNING to the UI process.
                    MasqueProcessState.write(this, "VERIFYING")
                    val verification = verifyMasqueTunnel()
                    if (verification.startsWith("OK:")) {
                        writeVerificationDiagnostic("14 verified $verification")
                        MasqueProcessState.write(this, "RUNNING")
                        getSystemService(NotificationManager::class.java).notify(
                            NOTIFICATION_ID,
                            notification("MASQUE verified · QUIC/UDP 443 · CONNECT-IP")
                        )
                        startHealthMonitor()
                    } else {
                        writeVerificationDiagnostic("ERROR: ${verification.removePrefix("ERROR:").trim()}")
                        shutdownForHandoff()
                    }
                } else {
                    writeVerificationDiagnostic(result)
                    shutdownForHandoff()
                }
            } finally {
                starting = false
            }
        }.start()

        return START_STICKY
    }


    /** Test Y: verify the exact transport plus real packet flow through the VPN. */
    private fun verifyMasqueTunnel(): String {
        val before = try { nativeTransportStatus() }
        catch (t: Throwable) { "ERROR: transport status failed: ${t.message ?: t.javaClass.simpleName}" }
        if (!before.startsWith("OK:")) return before
        if (!before.contains("quic=active") ||
            !before.contains("udp=") ||
            !before.contains(":443") ||
            !before.contains("connect_ip=established")) {
            return "ERROR: MASQUE transport verification did not confirm QUIC/UDP 443 CONNECT-IP"
        }

        val probe = try { tunnelProbe() }
        catch (t: Throwable) { "ERROR: tunnel probe failed: ${t.message ?: t.javaClass.simpleName}" }
        if (!probe.startsWith("OK:")) return probe

        val after = try { nativeTransportStatus() }
        catch (t: Throwable) { "ERROR: post-probe transport status failed: ${t.message ?: t.javaClass.simpleName}" }
        if (!after.startsWith("OK:")) return after
        val tx = Regex("(?:^|\\|)tx=(\\d+)").find(after)?.groupValues?.getOrNull(1)?.toLongOrNull() ?: 0L
        val rx = Regex("(?:^|\\|)rx=(\\d+)").find(after)?.groupValues?.getOrNull(1)?.toLongOrNull() ?: 0L
        if (tx <= 0L || rx <= 0L) {
            return "ERROR: tunnel probe returned but CONNECT-IP packet counters did not move (tx=$tx rx=$rx)"
        }
        return "OK: QUIC/UDP443 · CONNECT-IP · probe passed · tx=$tx rx=$rx"
    }

    /**
     * This socket is deliberately NOT protect()ed. Because the VPN has full routes,
     * Android sends it into our TUN; only the MASQUE outer QUIC socket is protected.
     * A successful HTTP response therefore proves usable bidirectional tunnel traffic.
     */
    private fun tunnelProbe(): String {
        val conn = (URL("https://www.cloudflare.com/cdn-cgi/trace?warpgo_test_y=1")
            .openConnection() as HttpURLConnection).apply {
            connectTimeout = 7000
            readTimeout = 7000
            instanceFollowRedirects = true
            useCaches = false
            setRequestProperty("Cache-Control", "no-cache")
            setRequestProperty("User-Agent", "WarpGo-TestY/1")
        }
        return try {
            val code = conn.responseCode
            val body = if (code in 200..299) conn.inputStream.bufferedReader().use { it.readText() } else ""
            if (code !in 200..299) return "ERROR: tunnel probe HTTP $code"
            if (!body.contains("ip=") || !body.contains("colo=")) {
                return "ERROR: tunnel probe response was not a Cloudflare trace response"
            }
            "OK: HTTP $code"
        } finally {
            conn.disconnect()
        }
    }

    private fun writeVerificationDiagnostic(text: String) {
        try { File(filesDir, "masque_testi_stage.txt").writeText(text + "\n") } catch (_: Throwable) {}
    }

    /**
     * Keep RUNNING honest after initial verification.  If the native QUIC/CONNECT-IP
     * session later dies, withdraw RUNNING and tear down the isolated service rather
     * than leaving a stale green UI state.
     */
    private fun startHealthMonitor() {
        Thread {
            while (!shuttingDown) {
                try { Thread.sleep(1500L) } catch (_: InterruptedException) { return@Thread }
                if (shuttingDown) return@Thread
                val status = try { nativeTransportStatus() }
                catch (t: Throwable) { "ERROR: ${t.message ?: t.javaClass.simpleName}" }
                if (!status.startsWith("OK:")) {
                    writeVerificationDiagnostic("ERROR: MASQUE health check: ${status.removePrefix("ERROR:").trim()}")
                    MasqueProcessState.write(this, "FAILED")
                    shutdownForHandoff()
                    return@Thread
                }
            }
        }.apply { name = "WarpGo-MASQUE-health"; isDaemon = true }.start()
    }

    private fun parseAddress(value: String, fallbackPrefix: Int): Pair<String, Int> {
        val trimmed = value.trim()
        if (trimmed.isBlank() || trimmed.startsWith("/")) return "" to fallbackPrefix
        val slash = trimmed.lastIndexOf('/')
        if (slash <= 0) return trimmed to fallbackPrefix
        val host = trimmed.substring(0, slash)
        val prefix = trimmed.substring(slash + 1).toIntOrNull() ?: fallbackPrefix
        return host to prefix
    }

    @Synchronized
    private fun shutdownForHandoff() {
        if (shuttingDown) return
        shuttingDown = true
        MasqueProcessState.write(this, "STOPPING")
        try { nativeStop() } catch (_: Throwable) {}
        try { pfd?.close() } catch (_: Throwable) {}
        pfd = null
        try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (_: Throwable) {}
        try { stopSelf() } catch (_: Throwable) {}
        // Keep instance non-null until Android actually calls onDestroy().
        // This makes isServiceActive() a real lifecycle signal rather than
        // reporting DOWN while the old VpnService is still being destroyed.
    }

    override fun onRevoke() {
        shutdownForHandoff()
        super.onRevoke()
    }

    override fun onDestroy() {
        shutdownForHandoff()
        if (instance === this) instance = null
        MasqueProcessState.write(this, "STOPPED")
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = super.onBind(intent)

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(CHANNEL, "Warp Go TV MASQUE", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    private fun notification(text: String) = NotificationCompat.Builder(this, CHANNEL)
        .setSmallIcon(android.R.drawable.stat_sys_download_done)
        .setContentTitle("Warp Go TV")
        .setContentText(text)
        .setOngoing(true)
        .setPriority(NotificationCompat.PRIORITY_LOW)
        .setContentIntent(
            PendingIntent.getActivity(
                this, 0, Intent(this, MainActivity::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        )
        .build()
}
