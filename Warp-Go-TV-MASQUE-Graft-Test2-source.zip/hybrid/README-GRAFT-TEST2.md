# Warp Go TV MASQUE Graft Test 2

Purpose: prove real VPN traffic can be carried by the MASQUE engine inside the Warp Go TV 1.5 Android host.

## Test scope
- WireGuard remains available and unchanged.
- A Protocol selector chooses WireGuard or MASQUE.
- MASQUE creates its own Android VpnService/TUN and routes TCP through Cloudflare MASQUE/HTTP/3.
- DNS is intercepted inside the TUN and resolved through the MASQUE tunnel.
- Non-DNS UDP is still direct in this proof-of-concept because the imported Cloudflare MASQUE implementation exposes TCP CONNECT, not CONNECT-UDP.
- This build is arm64-v8a only: phone + newer Fire TV first. Legacy/API25 is deliberately out of scope.

The UI status explicitly reports `Connected · WireGuard` or `Connected · MASQUE` so the active transport is unambiguous.
