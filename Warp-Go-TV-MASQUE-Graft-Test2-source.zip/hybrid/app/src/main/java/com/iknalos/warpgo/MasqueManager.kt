package com.iknalos.warpgo

import android.content.Context
import kotlinx.coroutines.delay

object MasqueManager {
    fun isUp(): Boolean = try { MasqueGraft.nativeIsRunning() } catch (_: Throwable) { false }

    suspend fun connect(context: Context) {
        MasqueVpnService.start(context.applicationContext)
        repeat(100) {
            if (isUp()) return
            val err = try { MasqueGraft.nativeLastError() } catch (_: Throwable) { "" }
            if (err.isNotBlank()) throw IllegalStateException(err)
            delay(100)
        }
        throw IllegalStateException("MASQUE connection timed out")
    }

    fun disconnect(context: Context) {
        MasqueVpnService.stop(context.applicationContext)
    }
}
