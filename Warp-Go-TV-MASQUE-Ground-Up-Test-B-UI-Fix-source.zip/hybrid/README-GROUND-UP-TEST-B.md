# Warp Go TV MASQUE – Ground-up Test B

Purpose: isolate the WireGuard UI/service lifecycle from the MASQUE native runtime while retaining the MASQUE test path.

Changes from Graft Test 2:
- WireGuard Connect and Disconnect use the original Warp Go 1.5 code path with no MASQUE JNI/state calls.
- UI state queries only the selected protocol.
- Protocol controls are disabled while the selected tunnel is active.
- MASQUE connect/disconnect path is otherwise unchanged.

Test sequence:
1. Select WireGuard, connect, confirm the activity stays open.
2. Disconnect WireGuard, confirm the activity stays open.
3. Select MASQUE, connect/disconnect and confirm its lifecycle remains clean.
