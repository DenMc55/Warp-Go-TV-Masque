package com.iknalos.warpgo

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object MasqueManager {
    fun isUp(): Boolean = try { MasqueGraft.nativeIsRunning() } catch (_: Throwable) { false }

    suspend fun connect(context: Context) {
        val result = withContext(Dispatchers.IO) {
            MasqueGraft.nativeTest(context.filesDir.absolutePath)
        }
        if (!result.startsWith("OK:")) {
            val detail = result.removePrefix("ERROR:").trim()
            throw IllegalStateException(if (detail.isBlank()) "MASQUE clean-core connection failed" else detail)
        }
    }

    fun disconnect(context: Context) {
        // Test C owns only the clean MASQUE QUIC/H3 core. Reuse the JNI stop
        // export without starting Android VpnService or creating catch-all routes.
        try { MasqueVpnService.stop(context.applicationContext) } catch (_: Throwable) {}
    }
}
