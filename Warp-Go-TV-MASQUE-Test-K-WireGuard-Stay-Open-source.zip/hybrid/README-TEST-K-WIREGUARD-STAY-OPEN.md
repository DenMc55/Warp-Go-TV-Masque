# Test K — WireGuard stay-open fix

Baseline: exact Test I UI source.

Only behavioural change: after a successful WireGuard connect, the existing Warp Go task is moved back to the foreground at 250 ms and 750 ms. MainActivity is not relaunched, so the Test I UI/layout is untouched.
