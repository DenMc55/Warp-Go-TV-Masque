//go:build android && cgo
package main

/*
#include <jni.h>
#include <stdlib.h>
static const char* jstringToChars(JNIEnv* env, jstring j) {
    if (j == NULL) return NULL;
    return (*env)->GetStringUTFChars(env, j, NULL);
}
static void releaseChars(JNIEnv* env, jstring j, const char* chars) {
    if (j != NULL && chars != NULL) (*env)->ReleaseStringUTFChars(env, j, chars);
}
static jstring newString(JNIEnv* env, const char* s) { return (*env)->NewStringUTF(env, s); }
*/
import "C"

import (
    "context"
    "crypto/tls"
    "fmt"
    "net"
    "os"
    "path/filepath"
    "strconv"
    "sync"
    "time"
    "unsafe"

    "warpmasque/registration"
    "warpmasque/tunnel"
)

var state struct {
    sync.Mutex
    client *tunnel.MasqueClient
    edge   string
}

func resultString(env *C.JNIEnv, s string) C.jstring {
    cs := C.CString(s)
    defer C.free(unsafe.Pointer(cs))
    return C.newString(env, cs)
}

func loadOrRegister(path string) (*registration.Registration, error) {
    if r, err := registration.Load(path); err == nil {
        return r, nil
    }
    r, err := registration.Register()
    if err != nil {
        return nil, err
    }
    if err := r.Save(path); err != nil {
        return nil, err
    }
    return r, nil
}

func edgeCandidates(r *registration.Registration) []string {
    ports := append([]int(nil), r.EndpointPorts...)
    if len(ports) == 0 {
        ports = []int{443, 4500, 500}
    }
    // Prefer the most web-like path first for this lifecycle-only test.
    ordered := []int{443}
    for _, p := range ports {
        if p != 443 {
            ordered = append(ordered, p)
        }
    }
    seen := map[string]bool{}
    out := []string{}
    for _, p := range ordered {
        for _, host := range []string{r.EndpointV4, r.EndpointV6} {
            if host == "" {
                continue
            }
            a := net.JoinHostPort(host, strconv.Itoa(p))
            if !seen[a] {
                seen[a] = true
                out = append(out, a)
            }
        }
    }
    return out
}

func buildTLS(r *registration.Registration) (*tls.Config, error) {
    verify, err := r.PeerPublicKeyVerifier()
    if err != nil {
        return nil, err
    }
    return &tls.Config{
        ServerName:         "consumer-masque-proxy.cloudflareclient.com",
        NextProtos:         []string{"h3"},
        InsecureSkipVerify: true,
        MinVersion:         tls.VersionTLS13,
        Certificates:       []tls.Certificate{r.ClientCert},
        VerifyPeerCertificate: verify,
        CurvePreferences:   []tls.CurveID{tls.CurveP256, tls.CurveP384, tls.CurveP521},
    }, nil
}

//export Java_com_iknalos_warpgo_MasqueLifecycle_nativeConnect
func Java_com_iknalos_warpgo_MasqueLifecycle_nativeConnect(env *C.JNIEnv, clazz C.jclass, filesDir C.jstring) C.jstring {
    chars := C.jstringToChars(env, filesDir)
    if chars == nil {
        return resultString(env, "MASQUE error: no files directory")
    }
    dir := C.GoString(chars)
    C.releaseChars(env, filesDir, chars)

    state.Lock()
    if state.client != nil {
        edge := state.edge
        state.Unlock()
        if edge == "" {
            return resultString(env, "MASQUE already connected")
        }
        return resultString(env, "MASQUE already connected · "+edge)
    }
    state.Unlock()

    if err := os.MkdirAll(dir, 0700); err != nil {
        return resultString(env, "MASQUE error: "+err.Error())
    }
    reg, err := loadOrRegister(filepath.Join(dir, "warpgo_masque_reg.json"))
    if err != nil {
        return resultString(env, "MASQUE registration failed: "+err.Error())
    }
    tc, err := buildTLS(reg)
    if err != nil {
        return resultString(env, "MASQUE TLS failed: "+err.Error())
    }
    edges := edgeCandidates(reg)
    if len(edges) == 0 {
        return resultString(env, "MASQUE error: no edge candidates")
    }

    ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
    defer cancel()
    client, err := tunnel.NewMasqueClientContext(ctx, edges, tc, reg.Token)
    if err != nil {
        return resultString(env, "MASQUE connect failed: "+err.Error())
    }

    // Test B intentionally creates no Android VPN/TUN. It only keeps the
    // independent MASQUE session alive so connect/disconnect/reconnect can be
    // exercised without touching Warp Go's proven WireGuard lifecycle.
    state.Lock()
    if state.client != nil {
        state.Unlock()
        _ = client.Close()
        return resultString(env, "MASQUE already connected")
    }
    state.client = client
    state.edge = "Cloudflare H3"
    state.Unlock()

    return resultString(env, fmt.Sprintf("MASQUE connected · H3 · %d edge candidates", len(edges)))
}

//export Java_com_iknalos_warpgo_MasqueLifecycle_nativeDisconnect
func Java_com_iknalos_warpgo_MasqueLifecycle_nativeDisconnect(env *C.JNIEnv, clazz C.jclass) C.jstring {
    state.Lock()
    client := state.client
    state.client = nil
    state.edge = ""
    state.Unlock()
    if client == nil {
        return resultString(env, "MASQUE already disconnected")
    }
    if err := client.Close(); err != nil {
        return resultString(env, "MASQUE disconnect warning: "+err.Error())
    }
    return resultString(env, "MASQUE disconnected cleanly")
}

//export Java_com_iknalos_warpgo_MasqueLifecycle_nativeIsConnected
func Java_com_iknalos_warpgo_MasqueLifecycle_nativeIsConnected(env *C.JNIEnv, clazz C.jclass) C.jboolean {
    state.Lock()
    connected := state.client != nil
    state.Unlock()
    if connected {
        return C.jboolean(1)
    }
    return C.jboolean(0)
}

func main() {}
