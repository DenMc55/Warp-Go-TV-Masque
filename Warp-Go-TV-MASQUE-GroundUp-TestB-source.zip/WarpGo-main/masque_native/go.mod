module warpmasque

go 1.26.5

require (
    github.com/quic-go/quic-go v0.61.0
    golang.org/x/crypto v0.54.0
    golang.org/x/net v0.56.0
)
