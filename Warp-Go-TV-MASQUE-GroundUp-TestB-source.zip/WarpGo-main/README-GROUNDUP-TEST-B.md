# Warp Go TV + MASQUE — Ground-Up Test B

Purpose: prove MASQUE session lifecycle can coexist with the untouched Warp Go TV 1.5 WireGuard path.

This build does NOT route device traffic through MASQUE and does NOT create a MASQUE Android VPN/TUN.

Test sequence:
1. Confirm WireGuard Connect/Disconnect still behaves exactly as Warp Go TV 1.5.
2. Disconnect WireGuard.
3. Press Connect MASQUE test. Expect `MASQUE connected · H3 ...`.
4. Disconnect MASQUE test. Expect clean disconnect.
5. Repeat MASQUE connect/disconnect several times.
6. Then connect WireGuard again. DNS/networking should still work immediately and the Activity should remain open.

Only after this lifecycle test passes should MASQUE be attached to the Android TUN.
