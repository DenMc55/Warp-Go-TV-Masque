package com.iknalos.warpgo

object MasqueLifecycle {
    init {
        System.loadLibrary("warpmasque")
    }

    external fun nativeConnect(filesDir: String): String
    external fun nativeDisconnect(): String
    external fun nativeIsConnected(): Boolean
}
