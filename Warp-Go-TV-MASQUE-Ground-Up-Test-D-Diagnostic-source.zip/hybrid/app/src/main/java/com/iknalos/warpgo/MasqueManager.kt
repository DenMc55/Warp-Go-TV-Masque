package com.iknalos.warpgo

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

object MasqueManager {
    private const val DIAGNOSTIC_FILE = "masque_testd_stage.txt"

    fun isUp(): Boolean = try {
        MasqueGraft.nativeIsRunning()
    } catch (_: Throwable) {
        false
    }

    fun lastDiagnostic(context: Context): String {
        return try {
            File(context.filesDir, DIAGNOSTIC_FILE).takeIf { it.exists() }
                ?.readText()
                ?.trim()
                .orEmpty()
        } catch (_: Throwable) {
            ""
        }
    }

    suspend fun connect(context: Context) {
        val result = try {
            withContext(Dispatchers.IO) {
                MasqueGraft.nativeTest(context.filesDir.absolutePath)
            }
        } catch (t: Throwable) {
            val stage = lastDiagnostic(context)
            val detail = t.message ?: t.javaClass.simpleName
            throw IllegalStateException(
                if (stage.isBlank()) "MASQUE Test D native failure: $detail"
                else "MASQUE Test D failed after [$stage]: $detail",
                t
            )
        }

        if (!result.startsWith("OK:")) {
            val detail = result.removePrefix("ERROR:").trim()
            val stage = lastDiagnostic(context)
            val message = when {
                detail.isNotBlank() && stage.isNotBlank() -> "$detail · $stage"
                detail.isNotBlank() -> detail
                stage.isNotBlank() -> stage
                else -> "MASQUE Test D diagnostic connection failed"
            }
            throw IllegalStateException(message)
        }
    }

    fun disconnect(context: Context) {
        try {
            MasqueVpnService.stop(context.applicationContext)
        } catch (_: Throwable) {
        }
    }
}
